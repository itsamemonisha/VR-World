﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0;
// UnityEngine.PostProcessing.MaterialFactory
struct MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05;
// UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<System.Object>
struct PostProcessingComponentRenderTexture_1_tD186BA4F88E53AEDB4483B3A95E19351FEEF5A95;
// UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.UserLutModel>
struct PostProcessingComponentRenderTexture_1_t618D4E8BC4B9B0827F11E4DBB5D3A0E271357D5A;
// UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.VignetteModel>
struct PostProcessingComponentRenderTexture_1_tBA02A691118838232E7AA7064B9206EA0F5784CC;
// UnityEngine.PostProcessing.PostProcessingComponent`1<System.Object>
struct PostProcessingComponent_1_t562A7C26319794908B2B93BF18B09D169F7965A3;
// UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.UserLutModel>
struct PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40;
// UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.VignetteModel>
struct PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A;
// UnityEngine.PostProcessing.PostProcessingContext
struct PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7;
// UnityEngine.PostProcessing.PostProcessingModel
struct PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A;
// UnityEngine.PostProcessing.PostProcessingProfile
struct PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F;
// UnityEngine.PostProcessing.RenderTextureFactory
struct RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236;
// UnityEngine.PostProcessing.TrackballAttribute
struct TrackballAttribute_tB3375811D20CE4C93838F6ED06772CE082FB8097;
// UnityEngine.PostProcessing.TrackballGroupAttribute
struct TrackballGroupAttribute_tE8A8F6CC21FF238290E5B538B49312624A56A7AF;
// UnityEngine.PostProcessing.UserLutComponent
struct UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE;
// UnityEngine.PostProcessing.UserLutModel
struct UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3;
// UnityEngine.PostProcessing.VignetteComponent
struct VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1;
// UnityEngine.PostProcessing.VignetteModel
struct VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968;
// UnityEngine.PropertyAttribute
struct PropertyAttribute_t25BFFC093C9C96E3CCF4EAB36F5DC6F937B1FA54;
// UnityEngine.Texture
struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;

IL2CPP_EXTERN_C RuntimeClass* GUI_t3E5CBC6B113E392EBBE1453DEF2B7CD020F345AA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral03026BC4446D19997BAAD711DD9B70CA6FD2DF56;
IL2CPP_EXTERN_C String_t* _stringLiteral1D6BAB4214360C1872E850772859FF1DEB889354;
IL2CPP_EXTERN_C String_t* _stringLiteral37B330CA7CE85B39C1850907AADCCC690FE10733;
IL2CPP_EXTERN_C String_t* _stringLiteral56FADA2DB070278072452622318577C11ACD5002;
IL2CPP_EXTERN_C String_t* _stringLiteral687A2CDBC9331B31676A8C3DA9A0ABABEC651D94;
IL2CPP_EXTERN_C String_t* _stringLiteral6EAC740C526B67B19AA2E4C9559FFC8F9AD7AE60;
IL2CPP_EXTERN_C String_t* _stringLiteral8A8B3459B7DD3D1C50EFDEDFFF3934E509D4884F;
IL2CPP_EXTERN_C String_t* _stringLiteralADA8FE61052C886547B312E505902966D7469C31;
IL2CPP_EXTERN_C String_t* _stringLiteralB4AD5A9B788FBC47ACCD99BABE7FD43CAC90263C;
IL2CPP_EXTERN_C String_t* _stringLiteralC1237627370FD34E3F69BE32DBFA5C67D1D851FC;
IL2CPP_EXTERN_C String_t* _stringLiteralC235B8920702F07A48DD2A22B385E4384C9A536E;
IL2CPP_EXTERN_C String_t* _stringLiteralC510EA100EEE1C261FE63B56E1F3390BFB85F481;
IL2CPP_EXTERN_C String_t* _stringLiteralEBB87034A642EC06F716E5311768CAEE3CA3E024;
IL2CPP_EXTERN_C String_t* _stringLiteralF4F2633F6EFA5C22185B8C0EB9E355910B24CFD2;
IL2CPP_EXTERN_C String_t* _stringLiteralF6EBE232F933484FDED979176585201E83489132;
IL2CPP_EXTERN_C const RuntimeMethod* PostProcessingComponentRenderTexture_1__ctor_m05C0C6322CF5C266F366F7AC9568C072C16E4870_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PostProcessingComponentRenderTexture_1__ctor_m306F0181A9F37100209A3340DC21F186BA879C1E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_RuntimeMethod_var;
IL2CPP_EXTERN_C const uint32_t Uniforms__cctor_mA2663CDFEC7B2ED77C78A899EC5CC903EC061BE2_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Uniforms__cctor_mE35E923121972C1045D2185D98C19090D3748F58_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Uniforms__cctor_mE896A281C010674DD689010BE6C91D3438899EA3_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t UserLutComponent_OnGUI_m2EB89A535861686796FE724F1826E064899C5E95_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t UserLutComponent_Prepare_m5D8E9AEECCAB23371404DECA85CE7A3014D0AAC9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t UserLutComponent__ctor_m6BDE4DF5D5AE258E3D1340BA1E1AC559185AE7C9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t UserLutComponent_get_active_m8428217EBA5B1257B2D45C1FE4059F72C09D665B_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t VignetteComponent_Prepare_m9088BC6708AC002872FADFD8681081DFA2696D1A_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t VignetteComponent__ctor_mBB15E7068E78A71AEB07345138FABB6F27E789A1_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t VignetteComponent_get_active_mF746C412DA78024BEF896F56DB353E4544A5E123_MetadataUsageId;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

struct Il2CppArrayBounds;

// System.Array


// System.Attribute
struct  Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74  : public RuntimeObject
{
public:

public:
};


// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// UnityEngine.PostProcessing.PostProcessingComponentBase
struct  PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942  : public RuntimeObject
{
public:
	// UnityEngine.PostProcessing.PostProcessingContext UnityEngine.PostProcessing.PostProcessingComponentBase::context
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * ___context_0;

public:
	inline static int32_t get_offset_of_context_0() { return static_cast<int32_t>(offsetof(PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942, ___context_0)); }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * get_context_0() const { return ___context_0; }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 ** get_address_of_context_0() { return &___context_0; }
	inline void set_context_0(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * value)
	{
		___context_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___context_0), (void*)value);
	}
};


// UnityEngine.PostProcessing.PostProcessingContext
struct  PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7  : public RuntimeObject
{
public:
	// UnityEngine.PostProcessing.PostProcessingProfile UnityEngine.PostProcessing.PostProcessingContext::profile
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * ___profile_0;
	// UnityEngine.Camera UnityEngine.PostProcessing.PostProcessingContext::camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___camera_1;
	// UnityEngine.PostProcessing.MaterialFactory UnityEngine.PostProcessing.PostProcessingContext::materialFactory
	MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * ___materialFactory_2;
	// UnityEngine.PostProcessing.RenderTextureFactory UnityEngine.PostProcessing.PostProcessingContext::renderTextureFactory
	RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * ___renderTextureFactory_3;
	// System.Boolean UnityEngine.PostProcessing.PostProcessingContext::<interrupted>k__BackingField
	bool ___U3CinterruptedU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_profile_0() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___profile_0)); }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * get_profile_0() const { return ___profile_0; }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F ** get_address_of_profile_0() { return &___profile_0; }
	inline void set_profile_0(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * value)
	{
		___profile_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___profile_0), (void*)value);
	}

	inline static int32_t get_offset_of_camera_1() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___camera_1)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_camera_1() const { return ___camera_1; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_camera_1() { return &___camera_1; }
	inline void set_camera_1(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___camera_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___camera_1), (void*)value);
	}

	inline static int32_t get_offset_of_materialFactory_2() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___materialFactory_2)); }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * get_materialFactory_2() const { return ___materialFactory_2; }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 ** get_address_of_materialFactory_2() { return &___materialFactory_2; }
	inline void set_materialFactory_2(MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * value)
	{
		___materialFactory_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___materialFactory_2), (void*)value);
	}

	inline static int32_t get_offset_of_renderTextureFactory_3() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___renderTextureFactory_3)); }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * get_renderTextureFactory_3() const { return ___renderTextureFactory_3; }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 ** get_address_of_renderTextureFactory_3() { return &___renderTextureFactory_3; }
	inline void set_renderTextureFactory_3(RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * value)
	{
		___renderTextureFactory_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___renderTextureFactory_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CinterruptedU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___U3CinterruptedU3Ek__BackingField_4)); }
	inline bool get_U3CinterruptedU3Ek__BackingField_4() const { return ___U3CinterruptedU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CinterruptedU3Ek__BackingField_4() { return &___U3CinterruptedU3Ek__BackingField_4; }
	inline void set_U3CinterruptedU3Ek__BackingField_4(bool value)
	{
		___U3CinterruptedU3Ek__BackingField_4 = value;
	}
};


// UnityEngine.PostProcessing.PostProcessingModel
struct  PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.PostProcessing.PostProcessingModel::m_Enabled
	bool ___m_Enabled_0;

public:
	inline static int32_t get_offset_of_m_Enabled_0() { return static_cast<int32_t>(offsetof(PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A, ___m_Enabled_0)); }
	inline bool get_m_Enabled_0() const { return ___m_Enabled_0; }
	inline bool* get_address_of_m_Enabled_0() { return &___m_Enabled_0; }
	inline void set_m_Enabled_0(bool value)
	{
		___m_Enabled_0 = value;
	}
};


// UnityEngine.PostProcessing.TaaComponent_Uniforms
struct  Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2  : public RuntimeObject
{
public:

public:
};

struct Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields
{
public:
	// System.Int32 UnityEngine.PostProcessing.TaaComponent_Uniforms::_Jitter
	int32_t ____Jitter_0;
	// System.Int32 UnityEngine.PostProcessing.TaaComponent_Uniforms::_SharpenParameters
	int32_t ____SharpenParameters_1;
	// System.Int32 UnityEngine.PostProcessing.TaaComponent_Uniforms::_FinalBlendParameters
	int32_t ____FinalBlendParameters_2;
	// System.Int32 UnityEngine.PostProcessing.TaaComponent_Uniforms::_HistoryTex
	int32_t ____HistoryTex_3;
	// System.Int32 UnityEngine.PostProcessing.TaaComponent_Uniforms::_MainTex
	int32_t ____MainTex_4;

public:
	inline static int32_t get_offset_of__Jitter_0() { return static_cast<int32_t>(offsetof(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields, ____Jitter_0)); }
	inline int32_t get__Jitter_0() const { return ____Jitter_0; }
	inline int32_t* get_address_of__Jitter_0() { return &____Jitter_0; }
	inline void set__Jitter_0(int32_t value)
	{
		____Jitter_0 = value;
	}

	inline static int32_t get_offset_of__SharpenParameters_1() { return static_cast<int32_t>(offsetof(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields, ____SharpenParameters_1)); }
	inline int32_t get__SharpenParameters_1() const { return ____SharpenParameters_1; }
	inline int32_t* get_address_of__SharpenParameters_1() { return &____SharpenParameters_1; }
	inline void set__SharpenParameters_1(int32_t value)
	{
		____SharpenParameters_1 = value;
	}

	inline static int32_t get_offset_of__FinalBlendParameters_2() { return static_cast<int32_t>(offsetof(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields, ____FinalBlendParameters_2)); }
	inline int32_t get__FinalBlendParameters_2() const { return ____FinalBlendParameters_2; }
	inline int32_t* get_address_of__FinalBlendParameters_2() { return &____FinalBlendParameters_2; }
	inline void set__FinalBlendParameters_2(int32_t value)
	{
		____FinalBlendParameters_2 = value;
	}

	inline static int32_t get_offset_of__HistoryTex_3() { return static_cast<int32_t>(offsetof(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields, ____HistoryTex_3)); }
	inline int32_t get__HistoryTex_3() const { return ____HistoryTex_3; }
	inline int32_t* get_address_of__HistoryTex_3() { return &____HistoryTex_3; }
	inline void set__HistoryTex_3(int32_t value)
	{
		____HistoryTex_3 = value;
	}

	inline static int32_t get_offset_of__MainTex_4() { return static_cast<int32_t>(offsetof(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields, ____MainTex_4)); }
	inline int32_t get__MainTex_4() const { return ____MainTex_4; }
	inline int32_t* get_address_of__MainTex_4() { return &____MainTex_4; }
	inline void set__MainTex_4(int32_t value)
	{
		____MainTex_4 = value;
	}
};


// UnityEngine.PostProcessing.UserLutComponent_Uniforms
struct  Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3  : public RuntimeObject
{
public:

public:
};

struct Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields
{
public:
	// System.Int32 UnityEngine.PostProcessing.UserLutComponent_Uniforms::_UserLut
	int32_t ____UserLut_0;
	// System.Int32 UnityEngine.PostProcessing.UserLutComponent_Uniforms::_UserLut_Params
	int32_t ____UserLut_Params_1;

public:
	inline static int32_t get_offset_of__UserLut_0() { return static_cast<int32_t>(offsetof(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields, ____UserLut_0)); }
	inline int32_t get__UserLut_0() const { return ____UserLut_0; }
	inline int32_t* get_address_of__UserLut_0() { return &____UserLut_0; }
	inline void set__UserLut_0(int32_t value)
	{
		____UserLut_0 = value;
	}

	inline static int32_t get_offset_of__UserLut_Params_1() { return static_cast<int32_t>(offsetof(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields, ____UserLut_Params_1)); }
	inline int32_t get__UserLut_Params_1() const { return ____UserLut_Params_1; }
	inline int32_t* get_address_of__UserLut_Params_1() { return &____UserLut_Params_1; }
	inline void set__UserLut_Params_1(int32_t value)
	{
		____UserLut_Params_1 = value;
	}
};


// UnityEngine.PostProcessing.VignetteComponent_Uniforms
struct  Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA  : public RuntimeObject
{
public:

public:
};

struct Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields
{
public:
	// System.Int32 UnityEngine.PostProcessing.VignetteComponent_Uniforms::_Vignette_Color
	int32_t ____Vignette_Color_0;
	// System.Int32 UnityEngine.PostProcessing.VignetteComponent_Uniforms::_Vignette_Center
	int32_t ____Vignette_Center_1;
	// System.Int32 UnityEngine.PostProcessing.VignetteComponent_Uniforms::_Vignette_Settings
	int32_t ____Vignette_Settings_2;
	// System.Int32 UnityEngine.PostProcessing.VignetteComponent_Uniforms::_Vignette_Mask
	int32_t ____Vignette_Mask_3;
	// System.Int32 UnityEngine.PostProcessing.VignetteComponent_Uniforms::_Vignette_Opacity
	int32_t ____Vignette_Opacity_4;

public:
	inline static int32_t get_offset_of__Vignette_Color_0() { return static_cast<int32_t>(offsetof(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields, ____Vignette_Color_0)); }
	inline int32_t get__Vignette_Color_0() const { return ____Vignette_Color_0; }
	inline int32_t* get_address_of__Vignette_Color_0() { return &____Vignette_Color_0; }
	inline void set__Vignette_Color_0(int32_t value)
	{
		____Vignette_Color_0 = value;
	}

	inline static int32_t get_offset_of__Vignette_Center_1() { return static_cast<int32_t>(offsetof(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields, ____Vignette_Center_1)); }
	inline int32_t get__Vignette_Center_1() const { return ____Vignette_Center_1; }
	inline int32_t* get_address_of__Vignette_Center_1() { return &____Vignette_Center_1; }
	inline void set__Vignette_Center_1(int32_t value)
	{
		____Vignette_Center_1 = value;
	}

	inline static int32_t get_offset_of__Vignette_Settings_2() { return static_cast<int32_t>(offsetof(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields, ____Vignette_Settings_2)); }
	inline int32_t get__Vignette_Settings_2() const { return ____Vignette_Settings_2; }
	inline int32_t* get_address_of__Vignette_Settings_2() { return &____Vignette_Settings_2; }
	inline void set__Vignette_Settings_2(int32_t value)
	{
		____Vignette_Settings_2 = value;
	}

	inline static int32_t get_offset_of__Vignette_Mask_3() { return static_cast<int32_t>(offsetof(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields, ____Vignette_Mask_3)); }
	inline int32_t get__Vignette_Mask_3() const { return ____Vignette_Mask_3; }
	inline int32_t* get_address_of__Vignette_Mask_3() { return &____Vignette_Mask_3; }
	inline void set__Vignette_Mask_3(int32_t value)
	{
		____Vignette_Mask_3 = value;
	}

	inline static int32_t get_offset_of__Vignette_Opacity_4() { return static_cast<int32_t>(offsetof(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields, ____Vignette_Opacity_4)); }
	inline int32_t get__Vignette_Opacity_4() const { return ____Vignette_Opacity_4; }
	inline int32_t* get_address_of__Vignette_Opacity_4() { return &____Vignette_Opacity_4; }
	inline void set__Vignette_Opacity_4(int32_t value)
	{
		____Vignette_Opacity_4 = value;
	}
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};


// UnityEngine.PostProcessing.PostProcessingComponent`1<System.Object>
struct  PostProcessingComponent_1_t562A7C26319794908B2B93BF18B09D169F7965A3  : public PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942
{
public:
	// T UnityEngine.PostProcessing.PostProcessingComponent`1::<model>k__BackingField
	RuntimeObject * ___U3CmodelU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CmodelU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessingComponent_1_t562A7C26319794908B2B93BF18B09D169F7965A3, ___U3CmodelU3Ek__BackingField_1)); }
	inline RuntimeObject * get_U3CmodelU3Ek__BackingField_1() const { return ___U3CmodelU3Ek__BackingField_1; }
	inline RuntimeObject ** get_address_of_U3CmodelU3Ek__BackingField_1() { return &___U3CmodelU3Ek__BackingField_1; }
	inline void set_U3CmodelU3Ek__BackingField_1(RuntimeObject * value)
	{
		___U3CmodelU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CmodelU3Ek__BackingField_1), (void*)value);
	}
};


// UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.UserLutModel>
struct  PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40  : public PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942
{
public:
	// T UnityEngine.PostProcessing.PostProcessingComponent`1::<model>k__BackingField
	UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * ___U3CmodelU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CmodelU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40, ___U3CmodelU3Ek__BackingField_1)); }
	inline UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * get_U3CmodelU3Ek__BackingField_1() const { return ___U3CmodelU3Ek__BackingField_1; }
	inline UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 ** get_address_of_U3CmodelU3Ek__BackingField_1() { return &___U3CmodelU3Ek__BackingField_1; }
	inline void set_U3CmodelU3Ek__BackingField_1(UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * value)
	{
		___U3CmodelU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CmodelU3Ek__BackingField_1), (void*)value);
	}
};


// UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.VignetteModel>
struct  PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A  : public PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942
{
public:
	// T UnityEngine.PostProcessing.PostProcessingComponent`1::<model>k__BackingField
	VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * ___U3CmodelU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CmodelU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A, ___U3CmodelU3Ek__BackingField_1)); }
	inline VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * get_U3CmodelU3Ek__BackingField_1() const { return ___U3CmodelU3Ek__BackingField_1; }
	inline VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 ** get_address_of_U3CmodelU3Ek__BackingField_1() { return &___U3CmodelU3Ek__BackingField_1; }
	inline void set_U3CmodelU3Ek__BackingField_1(VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * value)
	{
		___U3CmodelU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CmodelU3Ek__BackingField_1), (void*)value);
	}
};


// UnityEngine.PostProcessing.UserLutModel_Settings
struct  Settings_t89579C94217BC0734AF7DE292787FC983E2B4313 
{
public:
	// UnityEngine.Texture2D UnityEngine.PostProcessing.UserLutModel_Settings::lut
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	// System.Single UnityEngine.PostProcessing.UserLutModel_Settings::contribution
	float ___contribution_1;

public:
	inline static int32_t get_offset_of_lut_0() { return static_cast<int32_t>(offsetof(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313, ___lut_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_lut_0() const { return ___lut_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_lut_0() { return &___lut_0; }
	inline void set_lut_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___lut_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___lut_0), (void*)value);
	}

	inline static int32_t get_offset_of_contribution_1() { return static_cast<int32_t>(offsetof(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313, ___contribution_1)); }
	inline float get_contribution_1() const { return ___contribution_1; }
	inline float* get_address_of_contribution_1() { return &___contribution_1; }
	inline void set_contribution_1(float value)
	{
		___contribution_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.UserLutModel/Settings
struct Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_pinvoke
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	float ___contribution_1;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.UserLutModel/Settings
struct Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_com
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	float ___contribution_1;
};

// UnityEngine.PropertyAttribute
struct  PropertyAttribute_t25BFFC093C9C96E3CCF4EAB36F5DC6F937B1FA54  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:

public:
};


// UnityEngine.Rect
struct  Rect_t35B976DE901B5423C11705E156938EA27AB402CE 
{
public:
	// System.Single UnityEngine.Rect::m_XMin
	float ___m_XMin_0;
	// System.Single UnityEngine.Rect::m_YMin
	float ___m_YMin_1;
	// System.Single UnityEngine.Rect::m_Width
	float ___m_Width_2;
	// System.Single UnityEngine.Rect::m_Height
	float ___m_Height_3;

public:
	inline static int32_t get_offset_of_m_XMin_0() { return static_cast<int32_t>(offsetof(Rect_t35B976DE901B5423C11705E156938EA27AB402CE, ___m_XMin_0)); }
	inline float get_m_XMin_0() const { return ___m_XMin_0; }
	inline float* get_address_of_m_XMin_0() { return &___m_XMin_0; }
	inline void set_m_XMin_0(float value)
	{
		___m_XMin_0 = value;
	}

	inline static int32_t get_offset_of_m_YMin_1() { return static_cast<int32_t>(offsetof(Rect_t35B976DE901B5423C11705E156938EA27AB402CE, ___m_YMin_1)); }
	inline float get_m_YMin_1() const { return ___m_YMin_1; }
	inline float* get_address_of_m_YMin_1() { return &___m_YMin_1; }
	inline void set_m_YMin_1(float value)
	{
		___m_YMin_1 = value;
	}

	inline static int32_t get_offset_of_m_Width_2() { return static_cast<int32_t>(offsetof(Rect_t35B976DE901B5423C11705E156938EA27AB402CE, ___m_Width_2)); }
	inline float get_m_Width_2() const { return ___m_Width_2; }
	inline float* get_address_of_m_Width_2() { return &___m_Width_2; }
	inline void set_m_Width_2(float value)
	{
		___m_Width_2 = value;
	}

	inline static int32_t get_offset_of_m_Height_3() { return static_cast<int32_t>(offsetof(Rect_t35B976DE901B5423C11705E156938EA27AB402CE, ___m_Height_3)); }
	inline float get_m_Height_3() const { return ___m_Height_3; }
	inline float* get_address_of_m_Height_3() { return &___m_Height_3; }
	inline void set_m_Height_3(float value)
	{
		___m_Height_3 = value;
	}
};


// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// UnityEngine.Vector4
struct  Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___zeroVector_5)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___oneVector_6)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___negativeInfinityVector_8 = value;
	}
};


// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.UserLutModel>
struct  PostProcessingComponentRenderTexture_1_t618D4E8BC4B9B0827F11E4DBB5D3A0E271357D5A  : public PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40
{
public:

public:
};


// UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.VignetteModel>
struct  PostProcessingComponentRenderTexture_1_tBA02A691118838232E7AA7064B9206EA0F5784CC  : public PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A
{
public:

public:
};


// UnityEngine.PostProcessing.TrackballAttribute
struct  TrackballAttribute_tB3375811D20CE4C93838F6ED06772CE082FB8097  : public PropertyAttribute_t25BFFC093C9C96E3CCF4EAB36F5DC6F937B1FA54
{
public:
	// System.String UnityEngine.PostProcessing.TrackballAttribute::method
	String_t* ___method_0;

public:
	inline static int32_t get_offset_of_method_0() { return static_cast<int32_t>(offsetof(TrackballAttribute_tB3375811D20CE4C93838F6ED06772CE082FB8097, ___method_0)); }
	inline String_t* get_method_0() const { return ___method_0; }
	inline String_t** get_address_of_method_0() { return &___method_0; }
	inline void set_method_0(String_t* value)
	{
		___method_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_0), (void*)value);
	}
};


// UnityEngine.PostProcessing.TrackballGroupAttribute
struct  TrackballGroupAttribute_tE8A8F6CC21FF238290E5B538B49312624A56A7AF  : public PropertyAttribute_t25BFFC093C9C96E3CCF4EAB36F5DC6F937B1FA54
{
public:

public:
};


// UnityEngine.PostProcessing.UserLutModel
struct  UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.UserLutModel_Settings UnityEngine.PostProcessing.UserLutModel::m_Settings
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3, ___m_Settings_1)); }
	inline Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t89579C94217BC0734AF7DE292787FC983E2B4313 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  value)
	{
		___m_Settings_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Settings_1))->___lut_0), (void*)NULL);
	}
};


// UnityEngine.PostProcessing.VignetteModel_Mode
struct  Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D 
{
public:
	// System.Int32 UnityEngine.PostProcessing.VignetteModel_Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Material
struct  Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};


// UnityEngine.PostProcessing.UserLutComponent
struct  UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE  : public PostProcessingComponentRenderTexture_1_t618D4E8BC4B9B0827F11E4DBB5D3A0E271357D5A
{
public:

public:
};


// UnityEngine.PostProcessing.VignetteComponent
struct  VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1  : public PostProcessingComponentRenderTexture_1_tBA02A691118838232E7AA7064B9206EA0F5784CC
{
public:

public:
};


// UnityEngine.PostProcessing.VignetteModel_Settings
struct  Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C 
{
public:
	// UnityEngine.PostProcessing.VignetteModel_Mode UnityEngine.PostProcessing.VignetteModel_Settings::mode
	int32_t ___mode_0;
	// UnityEngine.Color UnityEngine.PostProcessing.VignetteModel_Settings::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	// UnityEngine.Vector2 UnityEngine.PostProcessing.VignetteModel_Settings::center
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	// System.Single UnityEngine.PostProcessing.VignetteModel_Settings::intensity
	float ___intensity_3;
	// System.Single UnityEngine.PostProcessing.VignetteModel_Settings::smoothness
	float ___smoothness_4;
	// System.Single UnityEngine.PostProcessing.VignetteModel_Settings::roundness
	float ___roundness_5;
	// UnityEngine.Texture UnityEngine.PostProcessing.VignetteModel_Settings::mask
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	// System.Single UnityEngine.PostProcessing.VignetteModel_Settings::opacity
	float ___opacity_7;
	// System.Boolean UnityEngine.PostProcessing.VignetteModel_Settings::rounded
	bool ___rounded_8;

public:
	inline static int32_t get_offset_of_mode_0() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___mode_0)); }
	inline int32_t get_mode_0() const { return ___mode_0; }
	inline int32_t* get_address_of_mode_0() { return &___mode_0; }
	inline void set_mode_0(int32_t value)
	{
		___mode_0 = value;
	}

	inline static int32_t get_offset_of_color_1() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___color_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_1() const { return ___color_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_1() { return &___color_1; }
	inline void set_color_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_1 = value;
	}

	inline static int32_t get_offset_of_center_2() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___center_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_center_2() const { return ___center_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_center_2() { return &___center_2; }
	inline void set_center_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___center_2 = value;
	}

	inline static int32_t get_offset_of_intensity_3() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___intensity_3)); }
	inline float get_intensity_3() const { return ___intensity_3; }
	inline float* get_address_of_intensity_3() { return &___intensity_3; }
	inline void set_intensity_3(float value)
	{
		___intensity_3 = value;
	}

	inline static int32_t get_offset_of_smoothness_4() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___smoothness_4)); }
	inline float get_smoothness_4() const { return ___smoothness_4; }
	inline float* get_address_of_smoothness_4() { return &___smoothness_4; }
	inline void set_smoothness_4(float value)
	{
		___smoothness_4 = value;
	}

	inline static int32_t get_offset_of_roundness_5() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___roundness_5)); }
	inline float get_roundness_5() const { return ___roundness_5; }
	inline float* get_address_of_roundness_5() { return &___roundness_5; }
	inline void set_roundness_5(float value)
	{
		___roundness_5 = value;
	}

	inline static int32_t get_offset_of_mask_6() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___mask_6)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_mask_6() const { return ___mask_6; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_mask_6() { return &___mask_6; }
	inline void set_mask_6(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___mask_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mask_6), (void*)value);
	}

	inline static int32_t get_offset_of_opacity_7() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___opacity_7)); }
	inline float get_opacity_7() const { return ___opacity_7; }
	inline float* get_address_of_opacity_7() { return &___opacity_7; }
	inline void set_opacity_7(float value)
	{
		___opacity_7 = value;
	}

	inline static int32_t get_offset_of_rounded_8() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___rounded_8)); }
	inline bool get_rounded_8() const { return ___rounded_8; }
	inline bool* get_address_of_rounded_8() { return &___rounded_8; }
	inline void set_rounded_8(bool value)
	{
		___rounded_8 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.VignetteModel/Settings
struct Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_pinvoke
{
	int32_t ___mode_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	float ___intensity_3;
	float ___smoothness_4;
	float ___roundness_5;
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	float ___opacity_7;
	int32_t ___rounded_8;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.VignetteModel/Settings
struct Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_com
{
	int32_t ___mode_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	float ___intensity_3;
	float ___smoothness_4;
	float ___roundness_5;
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	float ___opacity_7;
	int32_t ___rounded_8;
};

// UnityEngine.Texture
struct  Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4_StaticFields
{
public:
	// System.Int32 UnityEngine.Texture::GenerateAllMips
	int32_t ___GenerateAllMips_4;

public:
	inline static int32_t get_offset_of_GenerateAllMips_4() { return static_cast<int32_t>(offsetof(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4_StaticFields, ___GenerateAllMips_4)); }
	inline int32_t get_GenerateAllMips_4() const { return ___GenerateAllMips_4; }
	inline int32_t* get_address_of_GenerateAllMips_4() { return &___GenerateAllMips_4; }
	inline void set_GenerateAllMips_4(int32_t value)
	{
		___GenerateAllMips_4 = value;
	}
};


// UnityEngine.PostProcessing.VignetteModel
struct  VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.VignetteModel_Settings UnityEngine.PostProcessing.VignetteModel::m_Settings
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968, ___m_Settings_1)); }
	inline Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  value)
	{
		___m_Settings_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Settings_1))->___mask_6), (void*)NULL);
	}
};


// UnityEngine.Texture2D
struct  Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C  : public Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif


// T UnityEngine.PostProcessing.PostProcessingComponent`1<System.Object>::get_model()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR RuntimeObject * PostProcessingComponent_1_get_model_m09260CFA9D0B49BB169485505D58803ADBF57ACF_gshared_inline (PostProcessingComponent_1_t562A7C26319794908B2B93BF18B09D169F7965A3 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PostProcessingComponentRenderTexture_1__ctor_m378471F41AFABE2224871F97542DFB278A7FF9F1_gshared (PostProcessingComponentRenderTexture_1_tD186BA4F88E53AEDB4483B3A95E19351FEEF5A95 * __this, const RuntimeMethod* method);

// System.Int32 UnityEngine.Shader::PropertyToID(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45 (String_t* ___name0, const RuntimeMethod* method);
// System.Void UnityEngine.PropertyAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PropertyAttribute__ctor_m7F5C473F39D5601486C1127DA0D52F2DC293FC35 (PropertyAttribute_t25BFFC093C9C96E3CCF4EAB36F5DC6F937B1FA54 * __this, const RuntimeMethod* method);
// T UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.UserLutModel>::get_model()
inline UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_inline (PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40 * __this, const RuntimeMethod* method)
{
	return ((  UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * (*) (PostProcessingComponent_1_t0F9B8C4A5C7CFDCC410C3DEA0B36984A51816B40 *, const RuntimeMethod*))PostProcessingComponent_1_get_model_m09260CFA9D0B49BB169485505D58803ADBF57ACF_gshared_inline)(__this, method);
}
// UnityEngine.PostProcessing.UserLutModel/Settings UnityEngine.PostProcessing.UserLutModel::get_settings()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5_inline (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.PostProcessing.PostProcessingModel::get_enabled()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885_inline (PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1 (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___x0, Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___y1, const RuntimeMethod* method);
// System.Boolean UnityEngine.PostProcessing.PostProcessingContext::get_interrupted()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F_inline (PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Material::EnableKeyword(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9 (Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * __this, String_t* ___keyword0, const RuntimeMethod* method);
// System.Void UnityEngine.Material::SetTexture(System.Int32,UnityEngine.Texture)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_SetTexture_m4FFF0B403A64253B83534701104F017840142ACA (Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * __this, int32_t ___nameID0, Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___value1, const RuntimeMethod* method);
// System.Void UnityEngine.Vector4::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Vector4__ctor_m545458525879607A5392A10B175D0C19B2BC715D (Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * __this, float ___x0, float ___y1, float ___z2, float ___w3, const RuntimeMethod* method);
// System.Void UnityEngine.Material::SetVector(System.Int32,UnityEngine.Vector4)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA (Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * __this, int32_t ___nameID0, Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___value1, const RuntimeMethod* method);
// UnityEngine.Rect UnityEngine.PostProcessing.PostProcessingContext::get_viewport()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Rect_t35B976DE901B5423C11705E156938EA27AB402CE  PostProcessingContext_get_viewport_mCED91DA77E2AACCF2B70F1F712DADF5EADDDC58F (PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * __this, const RuntimeMethod* method);
// System.Single UnityEngine.Rect::get_x()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Rect_get_x_mC51A461F546D14832EB96B11A7198DADDE2597B7 (Rect_t35B976DE901B5423C11705E156938EA27AB402CE * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Screen::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Screen_get_width_m8ECCEF7FF17395D1237BC0193D7A6640A3FEEAD3 (const RuntimeMethod* method);
// System.Void UnityEngine.Rect::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Rect__ctor_m50B92C75005C9C5A0D05E6E0EBB43AFAF7C66280 (Rect_t35B976DE901B5423C11705E156938EA27AB402CE * __this, float ___x0, float ___y1, float ___width2, float ___height3, const RuntimeMethod* method);
// System.Void UnityEngine.GUI::DrawTexture(UnityEngine.Rect,UnityEngine.Texture)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GUI_DrawTexture_m6BD9AD550C8A2B133E0B7B4B570A55F6F7FF3030 (Rect_t35B976DE901B5423C11705E156938EA27AB402CE  ___position0, Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___image1, const RuntimeMethod* method);
// System.Void UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.UserLutModel>::.ctor()
inline void PostProcessingComponentRenderTexture_1__ctor_m05C0C6322CF5C266F366F7AC9568C072C16E4870 (PostProcessingComponentRenderTexture_1_t618D4E8BC4B9B0827F11E4DBB5D3A0E271357D5A * __this, const RuntimeMethod* method)
{
	((  void (*) (PostProcessingComponentRenderTexture_1_t618D4E8BC4B9B0827F11E4DBB5D3A0E271357D5A *, const RuntimeMethod*))PostProcessingComponentRenderTexture_1__ctor_m378471F41AFABE2224871F97542DFB278A7FF9F1_gshared)(__this, method);
}
// UnityEngine.PostProcessing.UserLutModel/Settings UnityEngine.PostProcessing.UserLutModel/Settings::get_defaultSettings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B (const RuntimeMethod* method);
// System.Void UnityEngine.PostProcessing.PostProcessingModel::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PostProcessingModel__ctor_m6C73498EA865E867DFAC27A88B6D1F597CAAAC77 (PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A * __this, const RuntimeMethod* method);
// T UnityEngine.PostProcessing.PostProcessingComponent`1<UnityEngine.PostProcessing.VignetteModel>::get_model()
inline VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_inline (PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A * __this, const RuntimeMethod* method)
{
	return ((  VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * (*) (PostProcessingComponent_1_tD4C3B464953607F5F8F0C9E6CB2BC21512104B2A *, const RuntimeMethod*))PostProcessingComponent_1_get_model_m09260CFA9D0B49BB169485505D58803ADBF57ACF_gshared_inline)(__this, method);
}
// UnityEngine.PostProcessing.VignetteModel/Settings UnityEngine.PostProcessing.VignetteModel::get_settings()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63_inline (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Material::SetColor(System.Int32,UnityEngine.Color)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_SetColor_m48FBB701F6177B367EDFAC6BE896D183EF640725 (Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * __this, int32_t ___nameID0, Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___value1, const RuntimeMethod* method);
// UnityEngine.Vector4 UnityEngine.Vector4::op_Implicit(UnityEngine.Vector2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  Vector4_op_Implicit_m3CB789809FDA1B5598EC3C928B173C62FC152656 (Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___v0, const RuntimeMethod* method);
// System.Void UnityEngine.Material::SetFloat(System.Int32,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Material_SetFloat_mC2FDDF0798373DEE6BBA9B9FFFE03EC3CFB9BF47 (Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * __this, int32_t ___nameID0, float ___value1, const RuntimeMethod* method);
// System.Void UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<UnityEngine.PostProcessing.VignetteModel>::.ctor()
inline void PostProcessingComponentRenderTexture_1__ctor_m306F0181A9F37100209A3340DC21F186BA879C1E (PostProcessingComponentRenderTexture_1_tBA02A691118838232E7AA7064B9206EA0F5784CC * __this, const RuntimeMethod* method)
{
	((  void (*) (PostProcessingComponentRenderTexture_1_tBA02A691118838232E7AA7064B9206EA0F5784CC *, const RuntimeMethod*))PostProcessingComponentRenderTexture_1__ctor_m378471F41AFABE2224871F97542DFB278A7FF9F1_gshared)(__this, method);
}
// UnityEngine.PostProcessing.VignetteModel/Settings UnityEngine.PostProcessing.VignetteModel/Settings::get_defaultSettings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C (const RuntimeMethod* method);
// System.Void UnityEngine.Color::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Color__ctor_m20DF490CEB364C4FC36D7EE392640DF5B7420D7C (Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * __this, float ___r0, float ___g1, float ___b2, float ___a3, const RuntimeMethod* method);
// System.Void UnityEngine.Vector2::.ctor(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Vector2__ctor_mEE8FB117AB1F8DB746FB8B3EB4C0DA3BF2A230D0 (Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * __this, float ___x0, float ___y1, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.PostProcessing.TaaComponent_Uniforms::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Uniforms__cctor_mE35E923121972C1045D2185D98C19090D3748F58 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Uniforms__cctor_mE35E923121972C1045D2185D98C19090D3748F58_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// internal static int _Jitter               = Shader.PropertyToID("_Jitter");
		int32_t L_0 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteral687A2CDBC9331B31676A8C3DA9A0ABABEC651D94, /*hidden argument*/NULL);
		((Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var))->set__Jitter_0(L_0);
		// internal static int _SharpenParameters    = Shader.PropertyToID("_SharpenParameters");
		int32_t L_1 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralC1237627370FD34E3F69BE32DBFA5C67D1D851FC, /*hidden argument*/NULL);
		((Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var))->set__SharpenParameters_1(L_1);
		// internal static int _FinalBlendParameters = Shader.PropertyToID("_FinalBlendParameters");
		int32_t L_2 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralADA8FE61052C886547B312E505902966D7469C31, /*hidden argument*/NULL);
		((Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var))->set__FinalBlendParameters_2(L_2);
		// internal static int _HistoryTex           = Shader.PropertyToID("_HistoryTex");
		int32_t L_3 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralB4AD5A9B788FBC47ACCD99BABE7FD43CAC90263C, /*hidden argument*/NULL);
		((Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var))->set__HistoryTex_3(L_3);
		// internal static int _MainTex              = Shader.PropertyToID("_MainTex");
		int32_t L_4 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralC510EA100EEE1C261FE63B56E1F3390BFB85F481, /*hidden argument*/NULL);
		((Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t532C704B378C17259AFDFAEDA571B7CFCCDD06A2_il2cpp_TypeInfo_var))->set__MainTex_4(L_4);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.PostProcessing.TrackballAttribute::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TrackballAttribute__ctor_m29DE2CEE0A7467BE4F578AC7B762C94A1430C649 (TrackballAttribute_tB3375811D20CE4C93838F6ED06772CE082FB8097 * __this, String_t* ___method0, const RuntimeMethod* method)
{
	{
		// public TrackballAttribute(string method)
		PropertyAttribute__ctor_m7F5C473F39D5601486C1127DA0D52F2DC293FC35(__this, /*hidden argument*/NULL);
		// this.method = method;
		String_t* L_0 = ___method0;
		__this->set_method_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.PostProcessing.TrackballGroupAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TrackballGroupAttribute__ctor_m1B6EEB0B9F912A14F405EDF62A104E401E9FADE7 (TrackballGroupAttribute_tE8A8F6CC21FF238290E5B538B49312624A56A7AF * __this, const RuntimeMethod* method)
{
	{
		PropertyAttribute__ctor_m7F5C473F39D5601486C1127DA0D52F2DC293FC35(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean UnityEngine.PostProcessing.UserLutComponent::get_active()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool UserLutComponent_get_active_m8428217EBA5B1257B2D45C1FE4059F72C09D665B (UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (UserLutComponent_get_active_m8428217EBA5B1257B2D45C1FE4059F72C09D665B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// var settings = model.settings;
		UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * L_0 = PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_RuntimeMethod_var);
		NullCheck(L_0);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_1 = UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5_inline(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// return model.enabled
		//        && settings.lut != null
		//        && settings.contribution > 0f
		//        && settings.lut.height == (int)Mathf.Sqrt(settings.lut.width)
		//        && !context.interrupted;
		UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * L_2 = PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_RuntimeMethod_var);
		NullCheck(L_2);
		bool L_3 = PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885_inline(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0062;
		}
	}
	{
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_4 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_5 = L_4.get_lut_0();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_6 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_5, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0062;
		}
	}
	{
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_7 = V_0;
		float L_8 = L_7.get_contribution_1();
		if ((!(((float)L_8) > ((float)(0.0f)))))
		{
			goto IL_0062;
		}
	}
	{
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_9 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_10 = L_9.get_lut_0();
		NullCheck(L_10);
		int32_t L_11 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_10);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_12 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_13 = L_12.get_lut_0();
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_13);
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		float L_15 = sqrtf((((float)((float)L_14))));
		if ((!(((uint32_t)L_11) == ((uint32_t)(((int32_t)((int32_t)L_15)))))))
		{
			goto IL_0062;
		}
	}
	{
		PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * L_16 = ((PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942 *)__this)->get_context_0();
		NullCheck(L_16);
		bool L_17 = PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F_inline(L_16, /*hidden argument*/NULL);
		return (bool)((((int32_t)L_17) == ((int32_t)0))? 1 : 0);
	}

IL_0062:
	{
		return (bool)0;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutComponent::Prepare(UnityEngine.Material)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutComponent_Prepare_m5D8E9AEECCAB23371404DECA85CE7A3014D0AAC9 (UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * __this, Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___uberMaterial0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (UserLutComponent_Prepare_m5D8E9AEECCAB23371404DECA85CE7A3014D0AAC9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// var settings = model.settings;
		UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * L_0 = PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_RuntimeMethod_var);
		NullCheck(L_0);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_1 = UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5_inline(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// uberMaterial.EnableKeyword("USER_LUT");
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_2 = ___uberMaterial0;
		NullCheck(L_2);
		Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9(L_2, _stringLiteral03026BC4446D19997BAAD711DD9B70CA6FD2DF56, /*hidden argument*/NULL);
		// uberMaterial.SetTexture(Uniforms._UserLut, settings.lut);
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_3 = ___uberMaterial0;
		IL2CPP_RUNTIME_CLASS_INIT(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var);
		int32_t L_4 = ((Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var))->get__UserLut_0();
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_5 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_6 = L_5.get_lut_0();
		NullCheck(L_3);
		Material_SetTexture_m4FFF0B403A64253B83534701104F017840142ACA(L_3, L_4, L_6, /*hidden argument*/NULL);
		// uberMaterial.SetVector(Uniforms._UserLut_Params, new Vector4(1f / settings.lut.width, 1f / settings.lut.height, settings.lut.height - 1f, settings.contribution));
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_7 = ___uberMaterial0;
		int32_t L_8 = ((Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var))->get__UserLut_Params_1();
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_9 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_10 = L_9.get_lut_0();
		NullCheck(L_10);
		int32_t L_11 = VirtFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_10);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_12 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_13 = L_12.get_lut_0();
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_13);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_15 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_16 = L_15.get_lut_0();
		NullCheck(L_16);
		int32_t L_17 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_16);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_18 = V_0;
		float L_19 = L_18.get_contribution_1();
		Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  L_20;
		memset((&L_20), 0, sizeof(L_20));
		Vector4__ctor_m545458525879607A5392A10B175D0C19B2BC715D((&L_20), ((float)((float)(1.0f)/(float)(((float)((float)L_11))))), ((float)((float)(1.0f)/(float)(((float)((float)L_14))))), ((float)il2cpp_codegen_subtract((float)(((float)((float)L_17))), (float)(1.0f))), L_19, /*hidden argument*/NULL);
		NullCheck(L_7);
		Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA(L_7, L_8, L_20, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutComponent::OnGUI()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutComponent_OnGUI_m2EB89A535861686796FE724F1826E064899C5E95 (UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (UserLutComponent_OnGUI_m2EB89A535861686796FE724F1826E064899C5E95_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  V_0;
	memset((&V_0), 0, sizeof(V_0));
	Rect_t35B976DE901B5423C11705E156938EA27AB402CE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		// var settings = model.settings;
		UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * L_0 = PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m2BCA8E888C60B4C09D46D7A72C7FB70985187354_RuntimeMethod_var);
		NullCheck(L_0);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_1 = UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5_inline(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// var rect = new Rect(context.viewport.x * Screen.width + 8f, 8f, settings.lut.width, settings.lut.height);
		PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * L_2 = ((PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942 *)__this)->get_context_0();
		NullCheck(L_2);
		Rect_t35B976DE901B5423C11705E156938EA27AB402CE  L_3 = PostProcessingContext_get_viewport_mCED91DA77E2AACCF2B70F1F712DADF5EADDDC58F(L_2, /*hidden argument*/NULL);
		V_1 = L_3;
		float L_4 = Rect_get_x_mC51A461F546D14832EB96B11A7198DADDE2597B7((Rect_t35B976DE901B5423C11705E156938EA27AB402CE *)(&V_1), /*hidden argument*/NULL);
		int32_t L_5 = Screen_get_width_m8ECCEF7FF17395D1237BC0193D7A6640A3FEEAD3(/*hidden argument*/NULL);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_6 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_7 = L_6.get_lut_0();
		NullCheck(L_7);
		int32_t L_8 = VirtFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_7);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_9 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_10 = L_9.get_lut_0();
		NullCheck(L_10);
		int32_t L_11 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_10);
		Rect_t35B976DE901B5423C11705E156938EA27AB402CE  L_12;
		memset((&L_12), 0, sizeof(L_12));
		Rect__ctor_m50B92C75005C9C5A0D05E6E0EBB43AFAF7C66280((&L_12), ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)L_4, (float)(((float)((float)L_5))))), (float)(8.0f))), (8.0f), (((float)((float)L_8))), (((float)((float)L_11))), /*hidden argument*/NULL);
		// GUI.DrawTexture(rect, settings.lut);
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_13 = V_0;
		Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * L_14 = L_13.get_lut_0();
		IL2CPP_RUNTIME_CLASS_INIT(GUI_t3E5CBC6B113E392EBBE1453DEF2B7CD020F345AA_il2cpp_TypeInfo_var);
		GUI_DrawTexture_m6BD9AD550C8A2B133E0B7B4B570A55F6F7FF3030(L_12, L_14, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutComponent::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutComponent__ctor_m6BDE4DF5D5AE258E3D1340BA1E1AC559185AE7C9 (UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (UserLutComponent__ctor_m6BDE4DF5D5AE258E3D1340BA1E1AC559185AE7C9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		PostProcessingComponentRenderTexture_1__ctor_m05C0C6322CF5C266F366F7AC9568C072C16E4870(__this, /*hidden argument*/PostProcessingComponentRenderTexture_1__ctor_m05C0C6322CF5C266F366F7AC9568C072C16E4870_RuntimeMethod_var);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.PostProcessing.UserLutComponent_Uniforms::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Uniforms__cctor_mA2663CDFEC7B2ED77C78A899EC5CC903EC061BE2 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Uniforms__cctor_mA2663CDFEC7B2ED77C78A899EC5CC903EC061BE2_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// internal static readonly int _UserLut        = Shader.PropertyToID("_UserLut");
		int32_t L_0 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralEBB87034A642EC06F716E5311768CAEE3CA3E024, /*hidden argument*/NULL);
		((Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var))->set__UserLut_0(L_0);
		// internal static readonly int _UserLut_Params = Shader.PropertyToID("_UserLut_Params");
		int32_t L_1 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteral6EAC740C526B67B19AA2E4C9559FFC8F9AD7AE60, /*hidden argument*/NULL);
		((Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_t619697B92CC4E002A3E960279A26D85AD2B31AE3_il2cpp_TypeInfo_var))->set__UserLut_Params_1(L_1);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.PostProcessing.UserLutModel_Settings UnityEngine.PostProcessing.UserLutModel::get_settings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5 (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Settings; }
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = __this->get_m_Settings_1();
		return L_0;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutModel::set_settings(UnityEngine.PostProcessing.UserLutModel_Settings)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutModel_set_settings_m6D84900B98D22C6CBC1BD3C1744FE5C9D85D0878 (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  ___value0, const RuntimeMethod* method)
{
	{
		// set { m_Settings = value; }
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = ___value0;
		__this->set_m_Settings_1(L_0);
		// set { m_Settings = value; }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutModel::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutModel_Reset_m32E91747CC6A6E9F5AB19E5242E2533AA8ADF7F9 (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, const RuntimeMethod* method)
{
	{
		// m_Settings = Settings.defaultSettings;
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B(/*hidden argument*/NULL);
		__this->set_m_Settings_1(L_0);
		// }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.UserLutModel::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void UserLutModel__ctor_m6ED43BF3A5EAAC14CAC941EABD318AB87974D6D4 (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, const RuntimeMethod* method)
{
	{
		// Settings m_Settings = Settings.defaultSettings;
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B(/*hidden argument*/NULL);
		__this->set_m_Settings_1(L_0);
		PostProcessingModel__ctor_m6C73498EA865E867DFAC27A88B6D1F597CAAAC77(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.PostProcessing.UserLutModel/Settings
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_pinvoke(const Settings_t89579C94217BC0734AF7DE292787FC983E2B4313& unmarshaled, Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_pinvoke& marshaled)
{
	Exception_t* ___lut_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'lut' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___lut_0Exception, NULL);
}
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_pinvoke_back(const Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_pinvoke& marshaled, Settings_t89579C94217BC0734AF7DE292787FC983E2B4313& unmarshaled)
{
	Exception_t* ___lut_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'lut' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___lut_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.PostProcessing.UserLutModel/Settings
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_pinvoke_cleanup(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.PostProcessing.UserLutModel/Settings
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_com(const Settings_t89579C94217BC0734AF7DE292787FC983E2B4313& unmarshaled, Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_com& marshaled)
{
	Exception_t* ___lut_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'lut' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___lut_0Exception, NULL);
}
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_com_back(const Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_com& marshaled, Settings_t89579C94217BC0734AF7DE292787FC983E2B4313& unmarshaled)
{
	Exception_t* ___lut_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'lut' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___lut_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.PostProcessing.UserLutModel/Settings
IL2CPP_EXTERN_C void Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshal_com_cleanup(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_com& marshaled)
{
}
// UnityEngine.PostProcessing.UserLutModel_Settings UnityEngine.PostProcessing.UserLutModel_Settings::get_defaultSettings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B (const RuntimeMethod* method)
{
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// return new Settings
		// {
		//     lut = null,
		//     contribution = 1f
		// };
		il2cpp_codegen_initobj((&V_0), sizeof(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313 ));
		(&V_0)->set_lut_0((Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C *)NULL);
		(&V_0)->set_contribution_1((1.0f));
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = V_0;
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean UnityEngine.PostProcessing.VignetteComponent::get_active()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool VignetteComponent_get_active_mF746C412DA78024BEF896F56DB353E4544A5E123 (VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (VignetteComponent_get_active_mF746C412DA78024BEF896F56DB353E4544A5E123_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return model.enabled
		//        && !context.interrupted;
		VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * L_0 = PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_RuntimeMethod_var);
		NullCheck(L_0);
		bool L_1 = PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885_inline(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_001c;
		}
	}
	{
		PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * L_2 = ((PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942 *)__this)->get_context_0();
		NullCheck(L_2);
		bool L_3 = PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F_inline(L_2, /*hidden argument*/NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Void UnityEngine.PostProcessing.VignetteComponent::Prepare(UnityEngine.Material)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VignetteComponent_Prepare_m9088BC6708AC002872FADFD8681081DFA2696D1A (VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * __this, Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___uberMaterial0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (VignetteComponent_Prepare_m9088BC6708AC002872FADFD8681081DFA2696D1A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	float V_1 = 0.0f;
	float G_B3_0 = 0.0f;
	float G_B3_1 = 0.0f;
	float G_B3_2 = 0.0f;
	int32_t G_B3_3 = 0;
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * G_B3_4 = NULL;
	float G_B2_0 = 0.0f;
	float G_B2_1 = 0.0f;
	float G_B2_2 = 0.0f;
	int32_t G_B2_3 = 0;
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * G_B2_4 = NULL;
	float G_B4_0 = 0.0f;
	float G_B4_1 = 0.0f;
	float G_B4_2 = 0.0f;
	float G_B4_3 = 0.0f;
	int32_t G_B4_4 = 0;
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * G_B4_5 = NULL;
	{
		// var settings = model.settings;
		VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * L_0 = PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_inline(__this, /*hidden argument*/PostProcessingComponent_1_get_model_m71F3F36D7172B5F21ABE37810B1CFC7A86015267_RuntimeMethod_var);
		NullCheck(L_0);
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_1 = VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63_inline(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// uberMaterial.SetColor(Uniforms._Vignette_Color, settings.color);
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_2 = ___uberMaterial0;
		IL2CPP_RUNTIME_CLASS_INIT(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var);
		int32_t L_3 = ((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->get__Vignette_Color_0();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_4 = V_0;
		Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  L_5 = L_4.get_color_1();
		NullCheck(L_2);
		Material_SetColor_m48FBB701F6177B367EDFAC6BE896D183EF640725(L_2, L_3, L_5, /*hidden argument*/NULL);
		// if (settings.mode == VignetteModel.Mode.Classic)
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_6 = V_0;
		int32_t L_7 = L_6.get_mode_0();
		if (L_7)
		{
			goto IL_009e;
		}
	}
	{
		// uberMaterial.SetVector(Uniforms._Vignette_Center, settings.center);
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_8 = ___uberMaterial0;
		IL2CPP_RUNTIME_CLASS_INIT(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var);
		int32_t L_9 = ((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->get__Vignette_Center_1();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_10 = V_0;
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_11 = L_10.get_center_2();
		IL2CPP_RUNTIME_CLASS_INIT(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_il2cpp_TypeInfo_var);
		Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  L_12 = Vector4_op_Implicit_m3CB789809FDA1B5598EC3C928B173C62FC152656(L_11, /*hidden argument*/NULL);
		NullCheck(L_8);
		Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA(L_8, L_9, L_12, /*hidden argument*/NULL);
		// uberMaterial.EnableKeyword("VIGNETTE_CLASSIC");
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_13 = ___uberMaterial0;
		NullCheck(L_13);
		Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9(L_13, _stringLiteral37B330CA7CE85B39C1850907AADCCC690FE10733, /*hidden argument*/NULL);
		// float roundness = (1f - settings.roundness) * 6f + settings.roundness;
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_14 = V_0;
		float L_15 = L_14.get_roundness_5();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_16 = V_0;
		float L_17 = L_16.get_roundness_5();
		V_1 = ((float)il2cpp_codegen_add((float)((float)il2cpp_codegen_multiply((float)((float)il2cpp_codegen_subtract((float)(1.0f), (float)L_15)), (float)(6.0f))), (float)L_17));
		// uberMaterial.SetVector(Uniforms._Vignette_Settings, new Vector4(settings.intensity * 3f, settings.smoothness * 5f, roundness, settings.rounded ? 1f : 0f));
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_18 = ___uberMaterial0;
		int32_t L_19 = ((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->get__Vignette_Settings_2();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_20 = V_0;
		float L_21 = L_20.get_intensity_3();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_22 = V_0;
		float L_23 = L_22.get_smoothness_4();
		float L_24 = V_1;
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_25 = V_0;
		bool L_26 = L_25.get_rounded_8();
		G_B2_0 = L_24;
		G_B2_1 = ((float)il2cpp_codegen_multiply((float)L_23, (float)(5.0f)));
		G_B2_2 = ((float)il2cpp_codegen_multiply((float)L_21, (float)(3.0f)));
		G_B2_3 = L_19;
		G_B2_4 = L_18;
		if (L_26)
		{
			G_B3_0 = L_24;
			G_B3_1 = ((float)il2cpp_codegen_multiply((float)L_23, (float)(5.0f)));
			G_B3_2 = ((float)il2cpp_codegen_multiply((float)L_21, (float)(3.0f)));
			G_B3_3 = L_19;
			G_B3_4 = L_18;
			goto IL_008e;
		}
	}
	{
		G_B4_0 = (0.0f);
		G_B4_1 = G_B2_0;
		G_B4_2 = G_B2_1;
		G_B4_3 = G_B2_2;
		G_B4_4 = G_B2_3;
		G_B4_5 = G_B2_4;
		goto IL_0093;
	}

IL_008e:
	{
		G_B4_0 = (1.0f);
		G_B4_1 = G_B3_0;
		G_B4_2 = G_B3_1;
		G_B4_3 = G_B3_2;
		G_B4_4 = G_B3_3;
		G_B4_5 = G_B3_4;
	}

IL_0093:
	{
		Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  L_27;
		memset((&L_27), 0, sizeof(L_27));
		Vector4__ctor_m545458525879607A5392A10B175D0C19B2BC715D((&L_27), G_B4_3, G_B4_2, G_B4_1, G_B4_0, /*hidden argument*/NULL);
		NullCheck(G_B4_5);
		Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA(G_B4_5, G_B4_4, L_27, /*hidden argument*/NULL);
		// }
		return;
	}

IL_009e:
	{
		// else if (settings.mode == VignetteModel.Mode.Masked)
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_28 = V_0;
		int32_t L_29 = L_28.get_mode_0();
		if ((!(((uint32_t)L_29) == ((uint32_t)1))))
		{
			goto IL_00ef;
		}
	}
	{
		// if (settings.mask != null && settings.opacity > 0f)
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_30 = V_0;
		Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * L_31 = L_30.get_mask_6();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_32 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_31, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_32)
		{
			goto IL_00ef;
		}
	}
	{
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_33 = V_0;
		float L_34 = L_33.get_opacity_7();
		if ((!(((float)L_34) > ((float)(0.0f)))))
		{
			goto IL_00ef;
		}
	}
	{
		// uberMaterial.EnableKeyword("VIGNETTE_MASKED");
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_35 = ___uberMaterial0;
		NullCheck(L_35);
		Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9(L_35, _stringLiteralF6EBE232F933484FDED979176585201E83489132, /*hidden argument*/NULL);
		// uberMaterial.SetTexture(Uniforms._Vignette_Mask, settings.mask);
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_36 = ___uberMaterial0;
		IL2CPP_RUNTIME_CLASS_INIT(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var);
		int32_t L_37 = ((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->get__Vignette_Mask_3();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_38 = V_0;
		Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * L_39 = L_38.get_mask_6();
		NullCheck(L_36);
		Material_SetTexture_m4FFF0B403A64253B83534701104F017840142ACA(L_36, L_37, L_39, /*hidden argument*/NULL);
		// uberMaterial.SetFloat(Uniforms._Vignette_Opacity, settings.opacity);
		Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * L_40 = ___uberMaterial0;
		int32_t L_41 = ((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->get__Vignette_Opacity_4();
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_42 = V_0;
		float L_43 = L_42.get_opacity_7();
		NullCheck(L_40);
		Material_SetFloat_mC2FDDF0798373DEE6BBA9B9FFFE03EC3CFB9BF47(L_40, L_41, L_43, /*hidden argument*/NULL);
	}

IL_00ef:
	{
		// }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.VignetteComponent::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VignetteComponent__ctor_mBB15E7068E78A71AEB07345138FABB6F27E789A1 (VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (VignetteComponent__ctor_mBB15E7068E78A71AEB07345138FABB6F27E789A1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		PostProcessingComponentRenderTexture_1__ctor_m306F0181A9F37100209A3340DC21F186BA879C1E(__this, /*hidden argument*/PostProcessingComponentRenderTexture_1__ctor_m306F0181A9F37100209A3340DC21F186BA879C1E_RuntimeMethod_var);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.PostProcessing.VignetteComponent_Uniforms::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Uniforms__cctor_mE896A281C010674DD689010BE6C91D3438899EA3 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Uniforms__cctor_mE896A281C010674DD689010BE6C91D3438899EA3_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// internal static readonly int _Vignette_Color    = Shader.PropertyToID("_Vignette_Color");
		int32_t L_0 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteral56FADA2DB070278072452622318577C11ACD5002, /*hidden argument*/NULL);
		((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->set__Vignette_Color_0(L_0);
		// internal static readonly int _Vignette_Center   = Shader.PropertyToID("_Vignette_Center");
		int32_t L_1 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteral1D6BAB4214360C1872E850772859FF1DEB889354, /*hidden argument*/NULL);
		((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->set__Vignette_Center_1(L_1);
		// internal static readonly int _Vignette_Settings = Shader.PropertyToID("_Vignette_Settings");
		int32_t L_2 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralC235B8920702F07A48DD2A22B385E4384C9A536E, /*hidden argument*/NULL);
		((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->set__Vignette_Settings_2(L_2);
		// internal static readonly int _Vignette_Mask     = Shader.PropertyToID("_Vignette_Mask");
		int32_t L_3 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteral8A8B3459B7DD3D1C50EFDEDFFF3934E509D4884F, /*hidden argument*/NULL);
		((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->set__Vignette_Mask_3(L_3);
		// internal static readonly int _Vignette_Opacity  = Shader.PropertyToID("_Vignette_Opacity");
		int32_t L_4 = Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45(_stringLiteralF4F2633F6EFA5C22185B8C0EB9E355910B24CFD2, /*hidden argument*/NULL);
		((Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_StaticFields*)il2cpp_codegen_static_fields_for(Uniforms_tAC523706AA9D338C1D6CF5DC25F403BE0A5EB2FA_il2cpp_TypeInfo_var))->set__Vignette_Opacity_4(L_4);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.PostProcessing.VignetteModel_Settings UnityEngine.PostProcessing.VignetteModel::get_settings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63 (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Settings; }
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_0 = __this->get_m_Settings_1();
		return L_0;
	}
}
// System.Void UnityEngine.PostProcessing.VignetteModel::set_settings(UnityEngine.PostProcessing.VignetteModel_Settings)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VignetteModel_set_settings_mB247818E0FD41105B90761AE980C1CDC134B51A2 (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  ___value0, const RuntimeMethod* method)
{
	{
		// set { m_Settings = value; }
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_0 = ___value0;
		__this->set_m_Settings_1(L_0);
		// set { m_Settings = value; }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.VignetteModel::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VignetteModel_Reset_m36D38CA5180A97991C8786D2DFE5FE31BD3EFDBB (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, const RuntimeMethod* method)
{
	{
		// m_Settings = Settings.defaultSettings;
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_0 = Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C(/*hidden argument*/NULL);
		__this->set_m_Settings_1(L_0);
		// }
		return;
	}
}
// System.Void UnityEngine.PostProcessing.VignetteModel::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VignetteModel__ctor_m37B9F390432277C45BA510DD3AF3E641B146544D (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, const RuntimeMethod* method)
{
	{
		// Settings m_Settings = Settings.defaultSettings;
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_0 = Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C(/*hidden argument*/NULL);
		__this->set_m_Settings_1(L_0);
		PostProcessingModel__ctor_m6C73498EA865E867DFAC27A88B6D1F597CAAAC77(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.PostProcessing.VignetteModel/Settings
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_pinvoke(const Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C& unmarshaled, Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_pinvoke& marshaled)
{
	Exception_t* ___mask_6Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'mask' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___mask_6Exception, NULL);
}
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_pinvoke_back(const Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_pinvoke& marshaled, Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C& unmarshaled)
{
	Exception_t* ___mask_6Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'mask' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___mask_6Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.PostProcessing.VignetteModel/Settings
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_pinvoke_cleanup(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.PostProcessing.VignetteModel/Settings
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_com(const Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C& unmarshaled, Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_com& marshaled)
{
	Exception_t* ___mask_6Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'mask' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___mask_6Exception, NULL);
}
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_com_back(const Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_com& marshaled, Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C& unmarshaled)
{
	Exception_t* ___mask_6Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'mask' of type 'Settings': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___mask_6Exception, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.PostProcessing.VignetteModel/Settings
IL2CPP_EXTERN_C void Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshal_com_cleanup(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_com& marshaled)
{
}
// UnityEngine.PostProcessing.VignetteModel_Settings UnityEngine.PostProcessing.VignetteModel_Settings::get_defaultSettings()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C (const RuntimeMethod* method)
{
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// return new Settings
		// {
		//     mode = Mode.Classic,
		//     color = new Color(0f, 0f, 0f, 1f),
		//     center = new Vector2(0.5f, 0.5f),
		//     intensity = 0.45f,
		//     smoothness = 0.2f,
		//     roundness = 1f,
		//     mask = null,
		//     opacity = 1f,
		//     rounded = false
		// };
		il2cpp_codegen_initobj((&V_0), sizeof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C ));
		(&V_0)->set_mode_0(0);
		Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  L_0;
		memset((&L_0), 0, sizeof(L_0));
		Color__ctor_m20DF490CEB364C4FC36D7EE392640DF5B7420D7C((&L_0), (0.0f), (0.0f), (0.0f), (1.0f), /*hidden argument*/NULL);
		(&V_0)->set_color_1(L_0);
		Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  L_1;
		memset((&L_1), 0, sizeof(L_1));
		Vector2__ctor_mEE8FB117AB1F8DB746FB8B3EB4C0DA3BF2A230D0((&L_1), (0.5f), (0.5f), /*hidden argument*/NULL);
		(&V_0)->set_center_2(L_1);
		(&V_0)->set_intensity_3((0.45f));
		(&V_0)->set_smoothness_4((0.2f));
		(&V_0)->set_roundness_5((1.0f));
		(&V_0)->set_mask_6((Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 *)NULL);
		(&V_0)->set_opacity_7((1.0f));
		(&V_0)->set_rounded_8((bool)0);
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_2 = V_0;
		return L_2;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5_inline (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Settings; }
		Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  L_0 = __this->get_m_Settings_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885_inline (PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Enabled; }
		bool L_0 = __this->get_m_Enabled_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F_inline (PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * __this, const RuntimeMethod* method)
{
	{
		// public bool interrupted { get; private set; }
		bool L_0 = __this->get_U3CinterruptedU3Ek__BackingField_4();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63_inline (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Settings; }
		Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  L_0 = __this->get_m_Settings_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR RuntimeObject * PostProcessingComponent_1_get_model_m09260CFA9D0B49BB169485505D58803ADBF57ACF_gshared_inline (PostProcessingComponent_1_t562A7C26319794908B2B93BF18B09D169F7965A3 * __this, const RuntimeMethod* method)
{
	{
		// public T model { get; internal set; }
		RuntimeObject * L_0 = (RuntimeObject *)__this->get_U3CmodelU3Ek__BackingField_1();
		return (RuntimeObject *)L_0;
	}
}
