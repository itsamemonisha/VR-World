﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void FreeCam::Start()
extern void FreeCam_Start_mF5B1F688F6C531E10E6DFC2E94A9E8FEB651FF41 (void);
// 0x00000002 System.Void FreeCam::Update()
extern void FreeCam_Update_m9E408EF9883951D3C1CE549A51144A3ADF5CAB95 (void);
// 0x00000003 System.Void FreeCam::.ctor()
extern void FreeCam__ctor_m9C4332750C154E49B7BE864188DA948AF94422E7 (void);
// 0x00000004 System.Void ScrollUVWater::Start()
extern void ScrollUVWater_Start_m8B0296588EC6749DF1D8C3E4073A7066A52EF3BE (void);
// 0x00000005 System.Void ScrollUVWater::Update()
extern void ScrollUVWater_Update_m197A72FD435FA0C9131750CEC63E4C0AB8E8C04D (void);
// 0x00000006 System.Void ScrollUVWater::.ctor()
extern void ScrollUVWater__ctor_m52B05CDF5FE1FE547F0CD41A12F42D7D70CC1999 (void);
// 0x00000007 System.Void EditorMouseLook::.ctor()
extern void EditorMouseLook__ctor_mB690A47F1EA4A1DAB8AF0EA7B902EF2911754C7C (void);
// 0x00000008 System.Void NvrAdvancedWalk::Start()
extern void NvrAdvancedWalk_Start_mD10D9A64BBBF2E3C063D2662CD138F5502696D7B (void);
// 0x00000009 System.Void NvrAdvancedWalk::Update()
extern void NvrAdvancedWalk_Update_m7BD3A660E23C8CA63522660D0B78BD25F9596C77 (void);
// 0x0000000A System.Void NvrAdvancedWalk::AllowedToMove(System.Boolean)
extern void NvrAdvancedWalk_AllowedToMove_m7FC6764ECDA7E2AB4860196EE9EFA88F9F04D0F2 (void);
// 0x0000000B System.Void NvrAdvancedWalk::.ctor()
extern void NvrAdvancedWalk__ctor_m31AB362A2CA84C7008F45387A328C99BEA478D09 (void);
// 0x0000000C System.Void NvrAutofly::Start()
extern void NvrAutofly_Start_mC9DA30A17A97440B4BC78174CD20CBC9A462D848 (void);
// 0x0000000D System.Void NvrAutofly::Update()
extern void NvrAutofly_Update_mFADA15C4BA79A728BC0219517EAA32A523130BE0 (void);
// 0x0000000E System.Void NvrAutofly::.ctor()
extern void NvrAutofly__ctor_mD11B80F9C93930F8434902EE86F68D2ADB8C102C (void);
// 0x0000000F System.Void NvrAutowalk::Start()
extern void NvrAutowalk_Start_m7E552E80F0C69E506D8EEEAF856E4C7F8CD1D8BD (void);
// 0x00000010 System.Void NvrAutowalk::Update()
extern void NvrAutowalk_Update_m54AE367C1D7DF21AF3AC8FA9C5509A1A69E06541 (void);
// 0x00000011 System.Void NvrAutowalk::.ctor()
extern void NvrAutowalk__ctor_m71F63B8E8EC26AB2DF14E5AC8CA99588625ABB1C (void);
// 0x00000012 System.Void NvrBluetoothController::Start()
extern void NvrBluetoothController_Start_m0159793D111B52111DA6FB63E1B784C25C0C1B7B (void);
// 0x00000013 System.Void NvrBluetoothController::Update()
extern void NvrBluetoothController_Update_m0934D8FC30561F249F5399DFFB9B0B3D053A7BBC (void);
// 0x00000014 System.Void NvrBluetoothController::.ctor()
extern void NvrBluetoothController__ctor_m6219198542880799D4341BEBB8FFD3AA91570B55 (void);
// 0x00000015 System.Void NvrLookWalk::Start()
extern void NvrLookWalk_Start_m006379042FB6EE4A36C89B2B0EE0F5992C27C205 (void);
// 0x00000016 System.Void NvrLookWalk::Update()
extern void NvrLookWalk_Update_m03400A24A1059B11C1DF3A91EAACD56DF3EDA3F1 (void);
// 0x00000017 System.Void NvrLookWalk::.ctor()
extern void NvrLookWalk__ctor_m04F90ED3BD9FF9A06F0E82F9D41DF4E5B3630C13 (void);
// 0x00000018 System.Void NvrSimpleGazeInputModule::Start()
extern void NvrSimpleGazeInputModule_Start_m15580CF657A4AD1B602B06165C6FA7C4A8497DC4 (void);
// 0x00000019 System.Void NvrSimpleGazeInputModule::Process()
extern void NvrSimpleGazeInputModule_Process_m8776C499844F78B4C1144FBCE07761B24EC2B34B (void);
// 0x0000001A System.Void NvrSimpleGazeInputModule::HandleLook()
extern void NvrSimpleGazeInputModule_HandleLook_mF3C621197E88CB58D01C1077B5AABFE2619041C2 (void);
// 0x0000001B System.Void NvrSimpleGazeInputModule::HandleSelection()
extern void NvrSimpleGazeInputModule_HandleSelection_m58F13FC6CD5B39F82E277426B198AA470B1A7BFF (void);
// 0x0000001C System.Void NvrSimpleGazeInputModule::SetCenterOfScreen()
extern void NvrSimpleGazeInputModule_SetCenterOfScreen_m97989109D8275EE663FFB7E2200CFEB1AF042F5E (void);
// 0x0000001D System.Void NvrSimpleGazeInputModule::.ctor()
extern void NvrSimpleGazeInputModule__ctor_m730DA9A22205333CA7DC861C89E4D0BAB3F08AEF (void);
// 0x0000001E System.Void NvrWalkableSurface::Start()
extern void NvrWalkableSurface_Start_m36E40179C4D8393F1B2C1C745EA0F35BF12DBD49 (void);
// 0x0000001F System.Void NvrWalkableSurface::OnPointerEnter()
extern void NvrWalkableSurface_OnPointerEnter_m33327A49D2834C0A57B8B2EC9A32B963178713CB (void);
// 0x00000020 System.Void NvrWalkableSurface::OnPointerExit()
extern void NvrWalkableSurface_OnPointerExit_m7FF44F2913C0D46BD4E01B6758807FBB8C2FE64A (void);
// 0x00000021 System.Void NvrWalkableSurface::OnPointerClick()
extern void NvrWalkableSurface_OnPointerClick_m8F759B049EEC64BEC29E688A7C07B5BC28EB697A (void);
// 0x00000022 System.Void NvrWalkableSurface::OnPointerUp()
extern void NvrWalkableSurface_OnPointerUp_mA7C329150767D36CE9FE52D0CB2159688D64A6FF (void);
// 0x00000023 System.Void NvrWalkableSurface::OnPointerDown()
extern void NvrWalkableSurface_OnPointerDown_mB5D5AF84B208D42EA322F45CA63A69B03751697F (void);
// 0x00000024 System.Void NvrWalkableSurface::.ctor()
extern void NvrWalkableSurface__ctor_m0455B2198063FF80242162B3681A8982DDE9265A (void);
// 0x00000025 System.Void NvrWalkableSurface::<Start>b__5_0(UnityEngine.EventSystems.BaseEventData)
extern void NvrWalkableSurface_U3CStartU3Eb__5_0_mAF11A8404AD088B8F6BB718D78C7599D00FD072F (void);
// 0x00000026 System.Void NvrWalkableSurface::<Start>b__5_1(UnityEngine.EventSystems.BaseEventData)
extern void NvrWalkableSurface_U3CStartU3Eb__5_1_mF5AFA4A48FDEF3C226A2EBBFAAFFD220F0773B3A (void);
// 0x00000027 System.Void NvrWalkableSurface::<Start>b__5_2(UnityEngine.EventSystems.BaseEventData)
extern void NvrWalkableSurface_U3CStartU3Eb__5_2_m268BDFAD1037EC65E4FB856B961D0FAEB7AD61D8 (void);
// 0x00000028 System.Void NvrWalkableSurface::<Start>b__5_3(UnityEngine.EventSystems.BaseEventData)
extern void NvrWalkableSurface_U3CStartU3Eb__5_3_m2A2EFCC2DB472DDFB3A2C5372E9540035E713D8E (void);
// 0x00000029 System.Void NvrWalkableSurface::<Start>b__5_4(UnityEngine.EventSystems.BaseEventData)
extern void NvrWalkableSurface_U3CStartU3Eb__5_4_mBB71C01C1F5E232BA98E179C0393C98B9FEC4DCE (void);
// 0x0000002A System.Void NvrWaypointData::.ctor()
extern void NvrWaypointData__ctor_m7877B5426EACA3CDDFB0DD792F514D1EB322A609 (void);
// 0x0000002B System.Void UnityEngine.PostProcessing.GetSetAttribute::.ctor(System.String)
extern void GetSetAttribute__ctor_mB78D2364742AEFCF07D8F290356263F033EE6A61 (void);
// 0x0000002C System.Void UnityEngine.PostProcessing.MinAttribute::.ctor(System.Single)
extern void MinAttribute__ctor_m97852EBB1F8E9CF4F4164D0C1810B3D19238D6C2 (void);
// 0x0000002D System.Void UnityEngine.PostProcessing.TrackballAttribute::.ctor(System.String)
extern void TrackballAttribute__ctor_m29DE2CEE0A7467BE4F578AC7B762C94A1430C649 (void);
// 0x0000002E System.Void UnityEngine.PostProcessing.TrackballGroupAttribute::.ctor()
extern void TrackballGroupAttribute__ctor_m1B6EEB0B9F912A14F405EDF62A104E401E9FADE7 (void);
// 0x0000002F UnityEngine.PostProcessing.AmbientOcclusionComponent_OcclusionSource UnityEngine.PostProcessing.AmbientOcclusionComponent::get_occlusionSource()
extern void AmbientOcclusionComponent_get_occlusionSource_m70F9BD953816398C5D53C562E68021D978636874 (void);
// 0x00000030 System.Boolean UnityEngine.PostProcessing.AmbientOcclusionComponent::get_ambientOnlySupported()
extern void AmbientOcclusionComponent_get_ambientOnlySupported_m73040AB2E44029629F405012A458155725A5F98B (void);
// 0x00000031 System.Boolean UnityEngine.PostProcessing.AmbientOcclusionComponent::get_active()
extern void AmbientOcclusionComponent_get_active_mB2330BF78D5848902B4510C26053240CCF524B8C (void);
// 0x00000032 UnityEngine.DepthTextureMode UnityEngine.PostProcessing.AmbientOcclusionComponent::GetCameraFlags()
extern void AmbientOcclusionComponent_GetCameraFlags_mFAE738A41FD764C3793F307BD8832CD05EEAF0BE (void);
// 0x00000033 System.String UnityEngine.PostProcessing.AmbientOcclusionComponent::GetName()
extern void AmbientOcclusionComponent_GetName_m86DDB268262D55138E46D438FFB78E83102A938E (void);
// 0x00000034 UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.AmbientOcclusionComponent::GetCameraEvent()
extern void AmbientOcclusionComponent_GetCameraEvent_m07477337350B2F55AFC5CE499370455867C3968B (void);
// 0x00000035 System.Void UnityEngine.PostProcessing.AmbientOcclusionComponent::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void AmbientOcclusionComponent_PopulateCommandBuffer_m89E5BF7E24906A47DA1D948FE2D9352FF4AFF125 (void);
// 0x00000036 System.Void UnityEngine.PostProcessing.AmbientOcclusionComponent::.ctor()
extern void AmbientOcclusionComponent__ctor_mE1A80D750AA95DB83F91B808D4D361BE303C572F (void);
// 0x00000037 System.Boolean UnityEngine.PostProcessing.BloomComponent::get_active()
extern void BloomComponent_get_active_m0B60B922D6CF1835EE866C9804003D106ABC9360 (void);
// 0x00000038 System.Void UnityEngine.PostProcessing.BloomComponent::Prepare(UnityEngine.RenderTexture,UnityEngine.Material,UnityEngine.Texture)
extern void BloomComponent_Prepare_m84B367E0B792227B7C2259E00797026C101B6B20 (void);
// 0x00000039 System.Void UnityEngine.PostProcessing.BloomComponent::.ctor()
extern void BloomComponent__ctor_mBD2FE039C08EA1175AF172A1D50CE9B664ECE0D2 (void);
// 0x0000003A System.Boolean UnityEngine.PostProcessing.BuiltinDebugViewsComponent::get_active()
extern void BuiltinDebugViewsComponent_get_active_mA9EB56F0478526BFC269AD4C08B82AA144C6B843 (void);
// 0x0000003B UnityEngine.DepthTextureMode UnityEngine.PostProcessing.BuiltinDebugViewsComponent::GetCameraFlags()
extern void BuiltinDebugViewsComponent_GetCameraFlags_m4571BA49F5063EA22429FA7BA1B5E8E9191C52AE (void);
// 0x0000003C UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.BuiltinDebugViewsComponent::GetCameraEvent()
extern void BuiltinDebugViewsComponent_GetCameraEvent_m631353AA2D227CE3CB98548856466B3742B27BE1 (void);
// 0x0000003D System.String UnityEngine.PostProcessing.BuiltinDebugViewsComponent::GetName()
extern void BuiltinDebugViewsComponent_GetName_m0DC6AF116D118969CC80AE06144970BCBFFB8861 (void);
// 0x0000003E System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void BuiltinDebugViewsComponent_PopulateCommandBuffer_mE290FCC45E152D6616C08C1DA98F1ADA1F5547E1 (void);
// 0x0000003F System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::DepthPass(UnityEngine.Rendering.CommandBuffer)
extern void BuiltinDebugViewsComponent_DepthPass_m380EF17F1EE1B26DD619ADCC5E973E4F821B5916 (void);
// 0x00000040 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::DepthNormalsPass(UnityEngine.Rendering.CommandBuffer)
extern void BuiltinDebugViewsComponent_DepthNormalsPass_m8C1715B0F76ED17B41E327F5CE4E138E15913C7A (void);
// 0x00000041 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::MotionVectorsPass(UnityEngine.Rendering.CommandBuffer)
extern void BuiltinDebugViewsComponent_MotionVectorsPass_mD488C6C61E8FCB9EA35CD621B1CB9975EF28DDE6 (void);
// 0x00000042 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::PrepareArrows()
extern void BuiltinDebugViewsComponent_PrepareArrows_m04C364DCE5177F0C57BD8CEA38EFF5B99653EAD5 (void);
// 0x00000043 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::OnDisable()
extern void BuiltinDebugViewsComponent_OnDisable_m86100E0F48531E95E4C9473D7870BBC92948D84F (void);
// 0x00000044 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent::.ctor()
extern void BuiltinDebugViewsComponent__ctor_mE356ADF2CDB4CBB8D435659AB0F4191C117333A4 (void);
// 0x00000045 System.Boolean UnityEngine.PostProcessing.ChromaticAberrationComponent::get_active()
extern void ChromaticAberrationComponent_get_active_m7D368F73DC5ACA35593DE90E00C391502F9885EB (void);
// 0x00000046 System.Void UnityEngine.PostProcessing.ChromaticAberrationComponent::OnDisable()
extern void ChromaticAberrationComponent_OnDisable_m68D924D9161504019E6FC5FF1E66361C0E1BB88D (void);
// 0x00000047 System.Void UnityEngine.PostProcessing.ChromaticAberrationComponent::Prepare(UnityEngine.Material)
extern void ChromaticAberrationComponent_Prepare_m632672B73986E3CDA4D506F3FC315BF3C82F8CCC (void);
// 0x00000048 System.Void UnityEngine.PostProcessing.ChromaticAberrationComponent::.ctor()
extern void ChromaticAberrationComponent__ctor_m92C689EEF99E2909C854F791FA7AC62BD3E7CBE0 (void);
// 0x00000049 System.Boolean UnityEngine.PostProcessing.ColorGradingComponent::get_active()
extern void ColorGradingComponent_get_active_m76FB6862F31EDBB17C36902FE411671FEAB64F13 (void);
// 0x0000004A System.Single UnityEngine.PostProcessing.ColorGradingComponent::StandardIlluminantY(System.Single)
extern void ColorGradingComponent_StandardIlluminantY_mA64FF93EDC7E3CF1257836F19A3F6D92AC8FFC04 (void);
// 0x0000004B UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::CIExyToLMS(System.Single,System.Single)
extern void ColorGradingComponent_CIExyToLMS_m64212E8FC2D7034BBC11308EA91194B5D5ACC260 (void);
// 0x0000004C UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::CalculateColorBalance(System.Single,System.Single)
extern void ColorGradingComponent_CalculateColorBalance_mA465E684D3E727DC86F1896520369E1990253488 (void);
// 0x0000004D UnityEngine.Color UnityEngine.PostProcessing.ColorGradingComponent::NormalizeColor(UnityEngine.Color)
extern void ColorGradingComponent_NormalizeColor_m5E0660CCF0D8DB1A0D2C7E359D8DB4A9F7C2F4F0 (void);
// 0x0000004E UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::ClampVector(UnityEngine.Vector3,System.Single,System.Single)
extern void ColorGradingComponent_ClampVector_m6DF366595D54DE1E58DA6839653BAD38FA68536D (void);
// 0x0000004F UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetLiftValue(UnityEngine.Color)
extern void ColorGradingComponent_GetLiftValue_m85B45C45F1113D2493E8DE775CD78062AD66E14A (void);
// 0x00000050 UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetGammaValue(UnityEngine.Color)
extern void ColorGradingComponent_GetGammaValue_mDD279576E7A546613F9D3E4D0D7205539B5736DE (void);
// 0x00000051 UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetGainValue(UnityEngine.Color)
extern void ColorGradingComponent_GetGainValue_m9CFCD1A6F31FA01BDCE8781AB60A84EC70664249 (void);
// 0x00000052 System.Void UnityEngine.PostProcessing.ColorGradingComponent::CalculateLiftGammaGain(UnityEngine.Color,UnityEngine.Color,UnityEngine.Color,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void ColorGradingComponent_CalculateLiftGammaGain_m55F6078CA1BE1A0150422645F04D6C25429F32B5 (void);
// 0x00000053 UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetSlopeValue(UnityEngine.Color)
extern void ColorGradingComponent_GetSlopeValue_m0B47DB5B6B4F016B2929174F11A00AE149C4B1A8 (void);
// 0x00000054 UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetPowerValue(UnityEngine.Color)
extern void ColorGradingComponent_GetPowerValue_m20CF0604640F55A2C08BD7D91746DFF338E9B125 (void);
// 0x00000055 UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingComponent::GetOffsetValue(UnityEngine.Color)
extern void ColorGradingComponent_GetOffsetValue_m12B953F4A87E9B7A0F07CD3F30430A63E2D87D84 (void);
// 0x00000056 System.Void UnityEngine.PostProcessing.ColorGradingComponent::CalculateSlopePowerOffset(UnityEngine.Color,UnityEngine.Color,UnityEngine.Color,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void ColorGradingComponent_CalculateSlopePowerOffset_m6AACCEC175AE207B98F1BCD93E7C9DC6BEAF7163 (void);
// 0x00000057 UnityEngine.TextureFormat UnityEngine.PostProcessing.ColorGradingComponent::GetCurveFormat()
extern void ColorGradingComponent_GetCurveFormat_m9A10A892BE6D77F8B6214E2D2CAEDF2E49230A4B (void);
// 0x00000058 UnityEngine.Texture2D UnityEngine.PostProcessing.ColorGradingComponent::GetCurveTexture()
extern void ColorGradingComponent_GetCurveTexture_m1DABCAA3214DEABCE23281F4A8A090E46B08AC79 (void);
// 0x00000059 System.Boolean UnityEngine.PostProcessing.ColorGradingComponent::IsLogLutValid(UnityEngine.RenderTexture)
extern void ColorGradingComponent_IsLogLutValid_m606AC9EB30D7183147900B3A846DFD128C1B458F (void);
// 0x0000005A UnityEngine.RenderTextureFormat UnityEngine.PostProcessing.ColorGradingComponent::GetLutFormat()
extern void ColorGradingComponent_GetLutFormat_m867EA4444CF8FBD12A2F2B6F62881D9875C999A4 (void);
// 0x0000005B System.Void UnityEngine.PostProcessing.ColorGradingComponent::GenerateLut()
extern void ColorGradingComponent_GenerateLut_m043651CED856228F73388E50A029E0EA8774D384 (void);
// 0x0000005C System.Void UnityEngine.PostProcessing.ColorGradingComponent::Prepare(UnityEngine.Material)
extern void ColorGradingComponent_Prepare_mA1E712E3432AC653D6E2E0A7E802BC689FFA9C09 (void);
// 0x0000005D System.Void UnityEngine.PostProcessing.ColorGradingComponent::OnGUI()
extern void ColorGradingComponent_OnGUI_m5739ED4E204A8D56BED83DC3A9A562FDFC1F5F3B (void);
// 0x0000005E System.Void UnityEngine.PostProcessing.ColorGradingComponent::OnDisable()
extern void ColorGradingComponent_OnDisable_m4D95AE6438146DF8F5A9020CEDD6B30161ABB69A (void);
// 0x0000005F System.Void UnityEngine.PostProcessing.ColorGradingComponent::.ctor()
extern void ColorGradingComponent__ctor_m9DF6AF00D9D6A8FDFB05424D98CD08E5BDCF7B33 (void);
// 0x00000060 System.Boolean UnityEngine.PostProcessing.DepthOfFieldComponent::get_active()
extern void DepthOfFieldComponent_get_active_m8C900A01927CFB07C0F74E4756CA6CA7BD2C3E9C (void);
// 0x00000061 UnityEngine.DepthTextureMode UnityEngine.PostProcessing.DepthOfFieldComponent::GetCameraFlags()
extern void DepthOfFieldComponent_GetCameraFlags_mA37E541AF33930DC281FB2FA29604BAA41BCD1B5 (void);
// 0x00000062 System.Single UnityEngine.PostProcessing.DepthOfFieldComponent::CalculateFocalLength()
extern void DepthOfFieldComponent_CalculateFocalLength_mBCF186E2B4066FF4F1813A3D1200298CC7F1C9B9 (void);
// 0x00000063 System.Single UnityEngine.PostProcessing.DepthOfFieldComponent::CalculateMaxCoCRadius(System.Int32)
extern void DepthOfFieldComponent_CalculateMaxCoCRadius_m1B17A8072B986F3E67BF0EA2FBAE4A63B3C8188D (void);
// 0x00000064 System.Boolean UnityEngine.PostProcessing.DepthOfFieldComponent::CheckHistory(System.Int32,System.Int32)
extern void DepthOfFieldComponent_CheckHistory_m54CD5D5E241F656272A07CF8C93312380AF39539 (void);
// 0x00000065 UnityEngine.RenderTextureFormat UnityEngine.PostProcessing.DepthOfFieldComponent::SelectFormat(UnityEngine.RenderTextureFormat,UnityEngine.RenderTextureFormat)
extern void DepthOfFieldComponent_SelectFormat_mE40E7364B96E18AE75C6C090384EF2034F195666 (void);
// 0x00000066 System.Void UnityEngine.PostProcessing.DepthOfFieldComponent::Prepare(UnityEngine.RenderTexture,UnityEngine.Material,System.Boolean,UnityEngine.Vector2,System.Single)
extern void DepthOfFieldComponent_Prepare_m4763AEAAB0FD35F56899E607BCE09023A0B58807 (void);
// 0x00000067 System.Void UnityEngine.PostProcessing.DepthOfFieldComponent::OnDisable()
extern void DepthOfFieldComponent_OnDisable_m923BB095D604D4C027117CC9195569EE4B41875A (void);
// 0x00000068 System.Void UnityEngine.PostProcessing.DepthOfFieldComponent::.ctor()
extern void DepthOfFieldComponent__ctor_mCD94663F108DD3B104014AB90CC47B8B5F909B55 (void);
// 0x00000069 System.Boolean UnityEngine.PostProcessing.DitheringComponent::get_active()
extern void DitheringComponent_get_active_mC16AFBB316053FFD221071F7F47200C253735929 (void);
// 0x0000006A System.Void UnityEngine.PostProcessing.DitheringComponent::OnDisable()
extern void DitheringComponent_OnDisable_m92FD815A36D869F5FE7453F6F16ED27D8E55805E (void);
// 0x0000006B System.Void UnityEngine.PostProcessing.DitheringComponent::LoadNoiseTextures()
extern void DitheringComponent_LoadNoiseTextures_m4866E1B9627F4E816B83B040327EB3FA0CC5B8FA (void);
// 0x0000006C System.Void UnityEngine.PostProcessing.DitheringComponent::Prepare(UnityEngine.Material)
extern void DitheringComponent_Prepare_m6B5B9004C89D04D2DA8431E8284E9A73FDA9319D (void);
// 0x0000006D System.Void UnityEngine.PostProcessing.DitheringComponent::.ctor()
extern void DitheringComponent__ctor_mCABC635529463FA8DAFF9CF9BFF2BC6FC2FA59DC (void);
// 0x0000006E System.Boolean UnityEngine.PostProcessing.EyeAdaptationComponent::get_active()
extern void EyeAdaptationComponent_get_active_m4CE90ECB5144D6E1944621825DB792362E660704 (void);
// 0x0000006F System.Void UnityEngine.PostProcessing.EyeAdaptationComponent::ResetHistory()
extern void EyeAdaptationComponent_ResetHistory_mD387BB29ADBD308DC62A0C58910679079C0F0A5F (void);
// 0x00000070 System.Void UnityEngine.PostProcessing.EyeAdaptationComponent::OnEnable()
extern void EyeAdaptationComponent_OnEnable_mA4BDEBED24DDE8A0624EFFFA0A2DCAF2031BB643 (void);
// 0x00000071 System.Void UnityEngine.PostProcessing.EyeAdaptationComponent::OnDisable()
extern void EyeAdaptationComponent_OnDisable_mA2D0BE41EA1F225C26292EDB62E840E28FF2EC1A (void);
// 0x00000072 UnityEngine.Vector4 UnityEngine.PostProcessing.EyeAdaptationComponent::GetHistogramScaleOffsetRes()
extern void EyeAdaptationComponent_GetHistogramScaleOffsetRes_mC0466D3854AB8A8E927278BD8F2A7E44388B2CE8 (void);
// 0x00000073 UnityEngine.Texture UnityEngine.PostProcessing.EyeAdaptationComponent::Prepare(UnityEngine.RenderTexture,UnityEngine.Material)
extern void EyeAdaptationComponent_Prepare_mC53E218DB147508AB711E63B3F9978AF49E0FADB (void);
// 0x00000074 System.Void UnityEngine.PostProcessing.EyeAdaptationComponent::OnGUI()
extern void EyeAdaptationComponent_OnGUI_mAAE6B381F08A15C732BD3F49400F864627D61E27 (void);
// 0x00000075 System.Void UnityEngine.PostProcessing.EyeAdaptationComponent::.ctor()
extern void EyeAdaptationComponent__ctor_m9D364E527CF2EB77B524C5D7C3DEFDF1B8960EB1 (void);
// 0x00000076 System.Boolean UnityEngine.PostProcessing.FogComponent::get_active()
extern void FogComponent_get_active_m2751987EB333DB601029DE6A7591C0FA4B71C2A0 (void);
// 0x00000077 System.String UnityEngine.PostProcessing.FogComponent::GetName()
extern void FogComponent_GetName_m65CDC7A0C94664738A5E0D0CC98D76493B90BC4D (void);
// 0x00000078 UnityEngine.DepthTextureMode UnityEngine.PostProcessing.FogComponent::GetCameraFlags()
extern void FogComponent_GetCameraFlags_m8BF18DDF7CE926DA69601186C42035E96D41442F (void);
// 0x00000079 UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.FogComponent::GetCameraEvent()
extern void FogComponent_GetCameraEvent_m96E10D06DBCF19690D69DB5159252601E5010121 (void);
// 0x0000007A System.Void UnityEngine.PostProcessing.FogComponent::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void FogComponent_PopulateCommandBuffer_m5FC61F3A3CDEFA1908F8E3E5307BD76CF695CE5B (void);
// 0x0000007B System.Void UnityEngine.PostProcessing.FogComponent::.ctor()
extern void FogComponent__ctor_mF6E4C1CDE2AEABC55C030CA3740BD7D7CFA5B447 (void);
// 0x0000007C System.Boolean UnityEngine.PostProcessing.FxaaComponent::get_active()
extern void FxaaComponent_get_active_m0CE0B29E2A2596758849904AE17F61951496263B (void);
// 0x0000007D System.Void UnityEngine.PostProcessing.FxaaComponent::Render(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void FxaaComponent_Render_m883201F71BD4230F307AF7477CF573CEC9BE1748 (void);
// 0x0000007E System.Void UnityEngine.PostProcessing.FxaaComponent::.ctor()
extern void FxaaComponent__ctor_m656004B25A78E30A7B05466CDC7F42E9E0238DF8 (void);
// 0x0000007F System.Boolean UnityEngine.PostProcessing.GrainComponent::get_active()
extern void GrainComponent_get_active_m9BA422DDF0AFD50FF7EC154E2413B2CA64EE523A (void);
// 0x00000080 System.Void UnityEngine.PostProcessing.GrainComponent::OnDisable()
extern void GrainComponent_OnDisable_mDA215CE7CE794A6CE30662F9C434006338D4E933 (void);
// 0x00000081 System.Void UnityEngine.PostProcessing.GrainComponent::Prepare(UnityEngine.Material)
extern void GrainComponent_Prepare_mF3F212B3B90E05C654D82C3AA9D108D8F4C3DDFF (void);
// 0x00000082 System.Void UnityEngine.PostProcessing.GrainComponent::.ctor()
extern void GrainComponent__ctor_m86C87D37113534CF55DE3F65FC9AF08E39005632 (void);
// 0x00000083 UnityEngine.PostProcessing.MotionBlurComponent_ReconstructionFilter UnityEngine.PostProcessing.MotionBlurComponent::get_reconstructionFilter()
extern void MotionBlurComponent_get_reconstructionFilter_m2D51A337C27E28CD7B96FB59BB3E29C342F74F53 (void);
// 0x00000084 UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter UnityEngine.PostProcessing.MotionBlurComponent::get_frameBlendingFilter()
extern void MotionBlurComponent_get_frameBlendingFilter_m9F7CDE6D8C8B53FCD822A6CFC397E00185C851F6 (void);
// 0x00000085 System.Boolean UnityEngine.PostProcessing.MotionBlurComponent::get_active()
extern void MotionBlurComponent_get_active_m215475A8D0D83731028876DC1FEEEBAE1A7E4D0E (void);
// 0x00000086 System.String UnityEngine.PostProcessing.MotionBlurComponent::GetName()
extern void MotionBlurComponent_GetName_mF6A7512CFA0392201603489852D6C6AA78F37869 (void);
// 0x00000087 System.Void UnityEngine.PostProcessing.MotionBlurComponent::ResetHistory()
extern void MotionBlurComponent_ResetHistory_m3719C692707E23E5A8047A9DC9DB693E87700DB7 (void);
// 0x00000088 UnityEngine.DepthTextureMode UnityEngine.PostProcessing.MotionBlurComponent::GetCameraFlags()
extern void MotionBlurComponent_GetCameraFlags_m740F8262D6E7BB14747EB8581545305CF6C86233 (void);
// 0x00000089 UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.MotionBlurComponent::GetCameraEvent()
extern void MotionBlurComponent_GetCameraEvent_m52A3DFF25A1DE3875B32784EAB52487488C77745 (void);
// 0x0000008A System.Void UnityEngine.PostProcessing.MotionBlurComponent::OnEnable()
extern void MotionBlurComponent_OnEnable_mC70E688BC7993E8AEFBE2F6B7905A986D2317480 (void);
// 0x0000008B System.Void UnityEngine.PostProcessing.MotionBlurComponent::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void MotionBlurComponent_PopulateCommandBuffer_m12EC28892FAC680578A9445C00D25A003D18CD7E (void);
// 0x0000008C System.Void UnityEngine.PostProcessing.MotionBlurComponent::OnDisable()
extern void MotionBlurComponent_OnDisable_mF6477BA3DB95D4EBCC4451ED3E24B0439F47CD9D (void);
// 0x0000008D System.Void UnityEngine.PostProcessing.MotionBlurComponent::.ctor()
extern void MotionBlurComponent__ctor_m0C5BD352A7650DD8C5FFD7A31635485919126074 (void);
// 0x0000008E UnityEngine.DepthTextureMode UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::GetCameraFlags()
extern void ScreenSpaceReflectionComponent_GetCameraFlags_m8F442E276F930715FDEE7E1FD6EF38A5BAD0030C (void);
// 0x0000008F System.Boolean UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::get_active()
extern void ScreenSpaceReflectionComponent_get_active_m240BA4C4BE2A7F896AD973E16A98B52608C25E41 (void);
// 0x00000090 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::OnEnable()
extern void ScreenSpaceReflectionComponent_OnEnable_mBE0B89D66F04DFC19A32657EE5035F44464E6F66 (void);
// 0x00000091 System.String UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::GetName()
extern void ScreenSpaceReflectionComponent_GetName_m5594E95B415ED58AA0C94D5B2669DE3CFEC77D32 (void);
// 0x00000092 UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::GetCameraEvent()
extern void ScreenSpaceReflectionComponent_GetCameraEvent_mEB3D2DE975E43B91403B7839881AB3C327D9E69A (void);
// 0x00000093 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ScreenSpaceReflectionComponent_PopulateCommandBuffer_m174E3825418E57D7B9746DF7E32F19B64AEB4F88 (void);
// 0x00000094 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionComponent::.ctor()
extern void ScreenSpaceReflectionComponent__ctor_m91D6614234484CE3D0B515348333E69CEBD9679B (void);
// 0x00000095 System.Boolean UnityEngine.PostProcessing.TaaComponent::get_active()
extern void TaaComponent_get_active_m2350E4D88BFBE23BE6EA2A1C95FBBDBA7CD4BBD1 (void);
// 0x00000096 UnityEngine.DepthTextureMode UnityEngine.PostProcessing.TaaComponent::GetCameraFlags()
extern void TaaComponent_GetCameraFlags_m672C8089957E15DBF6FF4611D2B536284212B1C6 (void);
// 0x00000097 UnityEngine.Vector2 UnityEngine.PostProcessing.TaaComponent::get_jitterVector()
extern void TaaComponent_get_jitterVector_mFBA80D2CE7C5056A38ECAE11DCA6004C75A3FA74 (void);
// 0x00000098 System.Void UnityEngine.PostProcessing.TaaComponent::set_jitterVector(UnityEngine.Vector2)
extern void TaaComponent_set_jitterVector_m221CF97FE556CB4853648371AF270CE43280B369 (void);
// 0x00000099 System.Void UnityEngine.PostProcessing.TaaComponent::ResetHistory()
extern void TaaComponent_ResetHistory_m60D8ADC47F23D0888BCACBCDDC2A1D552BF114FD (void);
// 0x0000009A System.Void UnityEngine.PostProcessing.TaaComponent::SetProjectionMatrix(System.Func`2<UnityEngine.Vector2,UnityEngine.Matrix4x4>)
extern void TaaComponent_SetProjectionMatrix_m18AD08B73FFC2652ACAB70C825457BF0AC000656 (void);
// 0x0000009B System.Void UnityEngine.PostProcessing.TaaComponent::Render(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void TaaComponent_Render_m827CB31CC593C8D68444A639D709F17AD1B82C77 (void);
// 0x0000009C System.Single UnityEngine.PostProcessing.TaaComponent::GetHaltonValue(System.Int32,System.Int32)
extern void TaaComponent_GetHaltonValue_mBC105A450027028D9A18949FC83AC41161B91156 (void);
// 0x0000009D UnityEngine.Vector2 UnityEngine.PostProcessing.TaaComponent::GenerateRandomOffset()
extern void TaaComponent_GenerateRandomOffset_m451A5BB3CABF7F05C73707A19B6BA38251C808E6 (void);
// 0x0000009E UnityEngine.Matrix4x4 UnityEngine.PostProcessing.TaaComponent::GetPerspectiveProjectionMatrix(UnityEngine.Vector2)
extern void TaaComponent_GetPerspectiveProjectionMatrix_m3C72D8F9A69268E18D503A4038AE26B315348F68 (void);
// 0x0000009F UnityEngine.Matrix4x4 UnityEngine.PostProcessing.TaaComponent::GetOrthographicProjectionMatrix(UnityEngine.Vector2)
extern void TaaComponent_GetOrthographicProjectionMatrix_mECEBF0642C4EF5856B8FBFFD90DC0BDA655BD9E0 (void);
// 0x000000A0 System.Void UnityEngine.PostProcessing.TaaComponent::OnDisable()
extern void TaaComponent_OnDisable_m7A55C79856C3587402E31968973BCBD7EBD52E6E (void);
// 0x000000A1 System.Void UnityEngine.PostProcessing.TaaComponent::.ctor()
extern void TaaComponent__ctor_m22FEB2A7DC262673228C350F29A0B3D9E8F2BC91 (void);
// 0x000000A2 System.Boolean UnityEngine.PostProcessing.UserLutComponent::get_active()
extern void UserLutComponent_get_active_m8428217EBA5B1257B2D45C1FE4059F72C09D665B (void);
// 0x000000A3 System.Void UnityEngine.PostProcessing.UserLutComponent::Prepare(UnityEngine.Material)
extern void UserLutComponent_Prepare_m5D8E9AEECCAB23371404DECA85CE7A3014D0AAC9 (void);
// 0x000000A4 System.Void UnityEngine.PostProcessing.UserLutComponent::OnGUI()
extern void UserLutComponent_OnGUI_m2EB89A535861686796FE724F1826E064899C5E95 (void);
// 0x000000A5 System.Void UnityEngine.PostProcessing.UserLutComponent::.ctor()
extern void UserLutComponent__ctor_m6BDE4DF5D5AE258E3D1340BA1E1AC559185AE7C9 (void);
// 0x000000A6 System.Boolean UnityEngine.PostProcessing.VignetteComponent::get_active()
extern void VignetteComponent_get_active_mF746C412DA78024BEF896F56DB353E4544A5E123 (void);
// 0x000000A7 System.Void UnityEngine.PostProcessing.VignetteComponent::Prepare(UnityEngine.Material)
extern void VignetteComponent_Prepare_m9088BC6708AC002872FADFD8681081DFA2696D1A (void);
// 0x000000A8 System.Void UnityEngine.PostProcessing.VignetteComponent::.ctor()
extern void VignetteComponent__ctor_mBB15E7068E78A71AEB07345138FABB6F27E789A1 (void);
// 0x000000A9 UnityEngine.PostProcessing.AmbientOcclusionModel_Settings UnityEngine.PostProcessing.AmbientOcclusionModel::get_settings()
extern void AmbientOcclusionModel_get_settings_m9C36453B771E7EBA4E53F11B369C1BCF20E08549 (void);
// 0x000000AA System.Void UnityEngine.PostProcessing.AmbientOcclusionModel::set_settings(UnityEngine.PostProcessing.AmbientOcclusionModel_Settings)
extern void AmbientOcclusionModel_set_settings_m1912086621AB439FB5D5A22270486A35FF97302E (void);
// 0x000000AB System.Void UnityEngine.PostProcessing.AmbientOcclusionModel::Reset()
extern void AmbientOcclusionModel_Reset_mB78A4BE5D2C53270CE439143B10F0960119694A5 (void);
// 0x000000AC System.Void UnityEngine.PostProcessing.AmbientOcclusionModel::.ctor()
extern void AmbientOcclusionModel__ctor_mB55F4A00E65EA62DDBCB527494551BAE15E5C258 (void);
// 0x000000AD UnityEngine.PostProcessing.AntialiasingModel_Settings UnityEngine.PostProcessing.AntialiasingModel::get_settings()
extern void AntialiasingModel_get_settings_m48E6CC1150A5F6263D1FF2048AE92DDC0E6892F6 (void);
// 0x000000AE System.Void UnityEngine.PostProcessing.AntialiasingModel::set_settings(UnityEngine.PostProcessing.AntialiasingModel_Settings)
extern void AntialiasingModel_set_settings_mE1C7153719F8841DE16A98AE6AD2517B06E3289D (void);
// 0x000000AF System.Void UnityEngine.PostProcessing.AntialiasingModel::Reset()
extern void AntialiasingModel_Reset_m1E897598B70AD5E5E7096A9D1C6A4D923C987913 (void);
// 0x000000B0 System.Void UnityEngine.PostProcessing.AntialiasingModel::.ctor()
extern void AntialiasingModel__ctor_mDB833BEF202BED20ED04C0F1F6A8AEF38611BB2D (void);
// 0x000000B1 UnityEngine.PostProcessing.BloomModel_Settings UnityEngine.PostProcessing.BloomModel::get_settings()
extern void BloomModel_get_settings_m5275CBD5288F631F8A059DCBF58189A14E6AAFF7 (void);
// 0x000000B2 System.Void UnityEngine.PostProcessing.BloomModel::set_settings(UnityEngine.PostProcessing.BloomModel_Settings)
extern void BloomModel_set_settings_m6144736D09C7C027AFD8BC10C6E7906DCB3CAE5A (void);
// 0x000000B3 System.Void UnityEngine.PostProcessing.BloomModel::Reset()
extern void BloomModel_Reset_m7BEF633097291492978C6D21687B60241E790891 (void);
// 0x000000B4 System.Void UnityEngine.PostProcessing.BloomModel::.ctor()
extern void BloomModel__ctor_m4881E660097BFBF202BB4818377C3FB670F788F3 (void);
// 0x000000B5 UnityEngine.PostProcessing.BuiltinDebugViewsModel_Settings UnityEngine.PostProcessing.BuiltinDebugViewsModel::get_settings()
extern void BuiltinDebugViewsModel_get_settings_mF3203E7D0D8E79D23A54B7501E946500E328271D (void);
// 0x000000B6 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsModel::set_settings(UnityEngine.PostProcessing.BuiltinDebugViewsModel_Settings)
extern void BuiltinDebugViewsModel_set_settings_mF472A1B9051088013CF8924D4DA13A91E3BB8AC3 (void);
// 0x000000B7 System.Boolean UnityEngine.PostProcessing.BuiltinDebugViewsModel::get_willInterrupt()
extern void BuiltinDebugViewsModel_get_willInterrupt_m8754446ED1973FAAC71E0549D70FBE5D7597E059 (void);
// 0x000000B8 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsModel::Reset()
extern void BuiltinDebugViewsModel_Reset_mFAFC415FD7C35572D5A2F89D0F9654F478EE5A6B (void);
// 0x000000B9 System.Boolean UnityEngine.PostProcessing.BuiltinDebugViewsModel::IsModeActive(UnityEngine.PostProcessing.BuiltinDebugViewsModel_Mode)
extern void BuiltinDebugViewsModel_IsModeActive_m64820C64BB75E2D5308F062D90DA7341AC5394FE (void);
// 0x000000BA System.Void UnityEngine.PostProcessing.BuiltinDebugViewsModel::.ctor()
extern void BuiltinDebugViewsModel__ctor_mCB7371673F1AE78DF3EE1F829B26364326A5AFD6 (void);
// 0x000000BB UnityEngine.PostProcessing.ChromaticAberrationModel_Settings UnityEngine.PostProcessing.ChromaticAberrationModel::get_settings()
extern void ChromaticAberrationModel_get_settings_mC5B79A93335B22FE54D17B3F483FF400D90B0210 (void);
// 0x000000BC System.Void UnityEngine.PostProcessing.ChromaticAberrationModel::set_settings(UnityEngine.PostProcessing.ChromaticAberrationModel_Settings)
extern void ChromaticAberrationModel_set_settings_mAF78E27C5C42AD5007C7932B445909C2D0ED674F (void);
// 0x000000BD System.Void UnityEngine.PostProcessing.ChromaticAberrationModel::Reset()
extern void ChromaticAberrationModel_Reset_mDD238DA7D9984E65BD28CEBC81B150E736BC70C2 (void);
// 0x000000BE System.Void UnityEngine.PostProcessing.ChromaticAberrationModel::.ctor()
extern void ChromaticAberrationModel__ctor_m842EE062AAB76F15EB58CACD2AE2DCE50272DB3D (void);
// 0x000000BF UnityEngine.PostProcessing.ColorGradingModel_Settings UnityEngine.PostProcessing.ColorGradingModel::get_settings()
extern void ColorGradingModel_get_settings_m1AE5CBB9E2E9DB96A9F9F9B61F883CE6F7BDB1CA (void);
// 0x000000C0 System.Void UnityEngine.PostProcessing.ColorGradingModel::set_settings(UnityEngine.PostProcessing.ColorGradingModel_Settings)
extern void ColorGradingModel_set_settings_mE42AD9547CD1F45F43FA6E96B5C8464232D54FE0 (void);
// 0x000000C1 System.Boolean UnityEngine.PostProcessing.ColorGradingModel::get_isDirty()
extern void ColorGradingModel_get_isDirty_mD038D53F87E95799378AC3EF03BC85A3B90C220B (void);
// 0x000000C2 System.Void UnityEngine.PostProcessing.ColorGradingModel::set_isDirty(System.Boolean)
extern void ColorGradingModel_set_isDirty_m98CC6398671A6D5E9AC5263AAB4D9F9EF31291D7 (void);
// 0x000000C3 UnityEngine.RenderTexture UnityEngine.PostProcessing.ColorGradingModel::get_bakedLut()
extern void ColorGradingModel_get_bakedLut_mA985224BFA8F8272871DCA475FE22668EFD83095 (void);
// 0x000000C4 System.Void UnityEngine.PostProcessing.ColorGradingModel::set_bakedLut(UnityEngine.RenderTexture)
extern void ColorGradingModel_set_bakedLut_m6A89BD69BF4CC3EB0B464FB8112088F0C65CDCA4 (void);
// 0x000000C5 System.Void UnityEngine.PostProcessing.ColorGradingModel::Reset()
extern void ColorGradingModel_Reset_mC250F18368B19DBB312DF30B194FAE687DA9115D (void);
// 0x000000C6 System.Void UnityEngine.PostProcessing.ColorGradingModel::OnValidate()
extern void ColorGradingModel_OnValidate_m9C8E0180B2E525919E113A2D4B6531AAD63D3ABD (void);
// 0x000000C7 System.Void UnityEngine.PostProcessing.ColorGradingModel::.ctor()
extern void ColorGradingModel__ctor_mC81EA02326D4402CF22A425F21476C807BB99662 (void);
// 0x000000C8 UnityEngine.PostProcessing.DepthOfFieldModel_Settings UnityEngine.PostProcessing.DepthOfFieldModel::get_settings()
extern void DepthOfFieldModel_get_settings_mEE77E80777009ED26285FA95800061F2674A0691 (void);
// 0x000000C9 System.Void UnityEngine.PostProcessing.DepthOfFieldModel::set_settings(UnityEngine.PostProcessing.DepthOfFieldModel_Settings)
extern void DepthOfFieldModel_set_settings_m1F26545DE0F2839E3A5053C55CD8892236E4E983 (void);
// 0x000000CA System.Void UnityEngine.PostProcessing.DepthOfFieldModel::Reset()
extern void DepthOfFieldModel_Reset_mC774665064B671EE232013248CE570F51DB00729 (void);
// 0x000000CB System.Void UnityEngine.PostProcessing.DepthOfFieldModel::.ctor()
extern void DepthOfFieldModel__ctor_m9B8304485D99B948E1A096D4F84CA4027F94E5BF (void);
// 0x000000CC UnityEngine.PostProcessing.DitheringModel_Settings UnityEngine.PostProcessing.DitheringModel::get_settings()
extern void DitheringModel_get_settings_mC0B7FD09DF49DC8EE24434D27BA01E0F9B7B14CE (void);
// 0x000000CD System.Void UnityEngine.PostProcessing.DitheringModel::set_settings(UnityEngine.PostProcessing.DitheringModel_Settings)
extern void DitheringModel_set_settings_mFC15AC24B687DF396267286A865AC6C400A8FC4A (void);
// 0x000000CE System.Void UnityEngine.PostProcessing.DitheringModel::Reset()
extern void DitheringModel_Reset_m053FA68F846CD2DF125F67D8033C830EB335AAE9 (void);
// 0x000000CF System.Void UnityEngine.PostProcessing.DitheringModel::.ctor()
extern void DitheringModel__ctor_m982139BA8D4553156B59AD5BDDBF28F0C8269A30 (void);
// 0x000000D0 UnityEngine.PostProcessing.EyeAdaptationModel_Settings UnityEngine.PostProcessing.EyeAdaptationModel::get_settings()
extern void EyeAdaptationModel_get_settings_mB1E27441C7DFE7B86A6CA0792F772633BB0FF93F (void);
// 0x000000D1 System.Void UnityEngine.PostProcessing.EyeAdaptationModel::set_settings(UnityEngine.PostProcessing.EyeAdaptationModel_Settings)
extern void EyeAdaptationModel_set_settings_m40F9C581791DC0C526B25FCF62D9F340C6A59B6B (void);
// 0x000000D2 System.Void UnityEngine.PostProcessing.EyeAdaptationModel::Reset()
extern void EyeAdaptationModel_Reset_m7AE022D22BC264608E152B3F7EBA111607548F7F (void);
// 0x000000D3 System.Void UnityEngine.PostProcessing.EyeAdaptationModel::.ctor()
extern void EyeAdaptationModel__ctor_m41A8D6FA78C56041AEA8A31758A615EA83A69A29 (void);
// 0x000000D4 UnityEngine.PostProcessing.FogModel_Settings UnityEngine.PostProcessing.FogModel::get_settings()
extern void FogModel_get_settings_mCB7F6DCD80E62568148DC4248A63B839E33ED0EB (void);
// 0x000000D5 System.Void UnityEngine.PostProcessing.FogModel::set_settings(UnityEngine.PostProcessing.FogModel_Settings)
extern void FogModel_set_settings_m4DF9789BB320E1F1939A9C719D05EEB494DB2F16 (void);
// 0x000000D6 System.Void UnityEngine.PostProcessing.FogModel::Reset()
extern void FogModel_Reset_m466762B5F9506DEE7CA3858C836B752BB4F43904 (void);
// 0x000000D7 System.Void UnityEngine.PostProcessing.FogModel::.ctor()
extern void FogModel__ctor_mBB29F9E3F4657BCE22FB2106BEC5BEA71D6780C0 (void);
// 0x000000D8 UnityEngine.PostProcessing.GrainModel_Settings UnityEngine.PostProcessing.GrainModel::get_settings()
extern void GrainModel_get_settings_m7DCDBBF518F83B5C7B1BDD3AA16FDEEACD730052 (void);
// 0x000000D9 System.Void UnityEngine.PostProcessing.GrainModel::set_settings(UnityEngine.PostProcessing.GrainModel_Settings)
extern void GrainModel_set_settings_mE8C8F3697DD897C330A3A62668DB86AC79694CF3 (void);
// 0x000000DA System.Void UnityEngine.PostProcessing.GrainModel::Reset()
extern void GrainModel_Reset_m2CF00116501BD3BBF82D78FEF31D3B97CB698AA9 (void);
// 0x000000DB System.Void UnityEngine.PostProcessing.GrainModel::.ctor()
extern void GrainModel__ctor_m6202989714C6C665F5B32EF0B5756802B783EE19 (void);
// 0x000000DC UnityEngine.PostProcessing.MotionBlurModel_Settings UnityEngine.PostProcessing.MotionBlurModel::get_settings()
extern void MotionBlurModel_get_settings_mCF94831603AF0583B256A013888D47D41A24AC21 (void);
// 0x000000DD System.Void UnityEngine.PostProcessing.MotionBlurModel::set_settings(UnityEngine.PostProcessing.MotionBlurModel_Settings)
extern void MotionBlurModel_set_settings_m600724563E8760CBC5C3BCF585B08768FD5D970C (void);
// 0x000000DE System.Void UnityEngine.PostProcessing.MotionBlurModel::Reset()
extern void MotionBlurModel_Reset_m5FEADBB97B1A1589429FB6EF728D56D2207A1148 (void);
// 0x000000DF System.Void UnityEngine.PostProcessing.MotionBlurModel::.ctor()
extern void MotionBlurModel__ctor_m17AEF99E86E4EA714D24FAFF40B2B184AFEFAAE3 (void);
// 0x000000E0 UnityEngine.PostProcessing.ScreenSpaceReflectionModel_Settings UnityEngine.PostProcessing.ScreenSpaceReflectionModel::get_settings()
extern void ScreenSpaceReflectionModel_get_settings_mF5C5F456B5D4E524C1C92646370DB490EFAE683A (void);
// 0x000000E1 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionModel::set_settings(UnityEngine.PostProcessing.ScreenSpaceReflectionModel_Settings)
extern void ScreenSpaceReflectionModel_set_settings_mCA73C58C8BE7EED955AA2B45A2DF06BF013CBF0F (void);
// 0x000000E2 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionModel::Reset()
extern void ScreenSpaceReflectionModel_Reset_mE164FA0AE97662F846EE6ABA20A1FD7CA6CE6BEB (void);
// 0x000000E3 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionModel::.ctor()
extern void ScreenSpaceReflectionModel__ctor_m618438D2169ADD79CCD261DAA3278BE2654DDA57 (void);
// 0x000000E4 UnityEngine.PostProcessing.UserLutModel_Settings UnityEngine.PostProcessing.UserLutModel::get_settings()
extern void UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5 (void);
// 0x000000E5 System.Void UnityEngine.PostProcessing.UserLutModel::set_settings(UnityEngine.PostProcessing.UserLutModel_Settings)
extern void UserLutModel_set_settings_m6D84900B98D22C6CBC1BD3C1744FE5C9D85D0878 (void);
// 0x000000E6 System.Void UnityEngine.PostProcessing.UserLutModel::Reset()
extern void UserLutModel_Reset_m32E91747CC6A6E9F5AB19E5242E2533AA8ADF7F9 (void);
// 0x000000E7 System.Void UnityEngine.PostProcessing.UserLutModel::.ctor()
extern void UserLutModel__ctor_m6ED43BF3A5EAAC14CAC941EABD318AB87974D6D4 (void);
// 0x000000E8 UnityEngine.PostProcessing.VignetteModel_Settings UnityEngine.PostProcessing.VignetteModel::get_settings()
extern void VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63 (void);
// 0x000000E9 System.Void UnityEngine.PostProcessing.VignetteModel::set_settings(UnityEngine.PostProcessing.VignetteModel_Settings)
extern void VignetteModel_set_settings_mB247818E0FD41105B90761AE980C1CDC134B51A2 (void);
// 0x000000EA System.Void UnityEngine.PostProcessing.VignetteModel::Reset()
extern void VignetteModel_Reset_m36D38CA5180A97991C8786D2DFE5FE31BD3EFDBB (void);
// 0x000000EB System.Void UnityEngine.PostProcessing.VignetteModel::.ctor()
extern void VignetteModel__ctor_m37B9F390432277C45BA510DD3AF3E641B146544D (void);
// 0x000000EC System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnEnable()
extern void PostProcessingBehaviour_OnEnable_m8BADFBD1B04DD475B329022BCD897F94F2678755 (void);
// 0x000000ED System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnPreCull()
extern void PostProcessingBehaviour_OnPreCull_mDC3E596FCDDF46861B19AEDCEE7A030A462653E4 (void);
// 0x000000EE System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnPreRender()
extern void PostProcessingBehaviour_OnPreRender_mE53A4B7FDA37F6A3E3B617BEE2E71E984D9E3B0A (void);
// 0x000000EF System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnPostRender()
extern void PostProcessingBehaviour_OnPostRender_m73A70E45F70D1B274F0824F02DC52C18FCFF65D3 (void);
// 0x000000F0 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void PostProcessingBehaviour_OnRenderImage_mAFF54B8E5C2A7813F866143FA1F313F4463EE487 (void);
// 0x000000F1 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnGUI()
extern void PostProcessingBehaviour_OnGUI_mD41B14C04DBCEFE9B3C41B04A1003EA7F470E92B (void);
// 0x000000F2 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::OnDisable()
extern void PostProcessingBehaviour_OnDisable_mA80612BCA42C3900E322386CAF8A750FEF1E0E42 (void);
// 0x000000F3 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::ResetTemporalEffects()
extern void PostProcessingBehaviour_ResetTemporalEffects_m8370A2742A0977EA53E9E47ACE07FB3C4381772B (void);
// 0x000000F4 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::CheckObservers()
extern void PostProcessingBehaviour_CheckObservers_m9557CD7CB41BCC2E96B49079FC02CD7C7DC5B0AA (void);
// 0x000000F5 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::DisableComponents()
extern void PostProcessingBehaviour_DisableComponents_mC1AE3448D19621891B04526D2FAD0F7C90F12D37 (void);
// 0x000000F6 UnityEngine.Rendering.CommandBuffer UnityEngine.PostProcessing.PostProcessingBehaviour::AddCommandBuffer(UnityEngine.Rendering.CameraEvent,System.String)
// 0x000000F7 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::RemoveCommandBuffer()
// 0x000000F8 UnityEngine.Rendering.CommandBuffer UnityEngine.PostProcessing.PostProcessingBehaviour::GetCommandBuffer(UnityEngine.Rendering.CameraEvent,System.String)
// 0x000000F9 System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::TryExecuteCommandBuffer(UnityEngine.PostProcessing.PostProcessingComponentCommandBuffer`1<T>)
// 0x000000FA System.Boolean UnityEngine.PostProcessing.PostProcessingBehaviour::TryPrepareUberImageEffect(UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1<T>,UnityEngine.Material)
// 0x000000FB T UnityEngine.PostProcessing.PostProcessingBehaviour::AddComponent(T)
// 0x000000FC System.Void UnityEngine.PostProcessing.PostProcessingBehaviour::.ctor()
extern void PostProcessingBehaviour__ctor_mEBBEBD3D56E712F56F2604F1BB90926EC81F75D2 (void);
// 0x000000FD UnityEngine.DepthTextureMode UnityEngine.PostProcessing.PostProcessingComponentBase::GetCameraFlags()
extern void PostProcessingComponentBase_GetCameraFlags_m3C8D0EB0C179FD957F5D57CC88D4535D4F132C16 (void);
// 0x000000FE System.Boolean UnityEngine.PostProcessing.PostProcessingComponentBase::get_active()
// 0x000000FF System.Void UnityEngine.PostProcessing.PostProcessingComponentBase::OnEnable()
extern void PostProcessingComponentBase_OnEnable_m0085392683268055715EAD66095A02DA5017F089 (void);
// 0x00000100 System.Void UnityEngine.PostProcessing.PostProcessingComponentBase::OnDisable()
extern void PostProcessingComponentBase_OnDisable_m446E74F6E6C3AD45ED6831F999C0C34BDE161B39 (void);
// 0x00000101 UnityEngine.PostProcessing.PostProcessingModel UnityEngine.PostProcessing.PostProcessingComponentBase::GetModel()
// 0x00000102 System.Void UnityEngine.PostProcessing.PostProcessingComponentBase::.ctor()
extern void PostProcessingComponentBase__ctor_m95905EACEC14697C2FB1F6988D0B6AD44ED4C54A (void);
// 0x00000103 T UnityEngine.PostProcessing.PostProcessingComponent`1::get_model()
// 0x00000104 System.Void UnityEngine.PostProcessing.PostProcessingComponent`1::set_model(T)
// 0x00000105 System.Void UnityEngine.PostProcessing.PostProcessingComponent`1::Init(UnityEngine.PostProcessing.PostProcessingContext,T)
// 0x00000106 UnityEngine.PostProcessing.PostProcessingModel UnityEngine.PostProcessing.PostProcessingComponent`1::GetModel()
// 0x00000107 System.Void UnityEngine.PostProcessing.PostProcessingComponent`1::.ctor()
// 0x00000108 UnityEngine.Rendering.CameraEvent UnityEngine.PostProcessing.PostProcessingComponentCommandBuffer`1::GetCameraEvent()
// 0x00000109 System.String UnityEngine.PostProcessing.PostProcessingComponentCommandBuffer`1::GetName()
// 0x0000010A System.Void UnityEngine.PostProcessing.PostProcessingComponentCommandBuffer`1::PopulateCommandBuffer(UnityEngine.Rendering.CommandBuffer)
// 0x0000010B System.Void UnityEngine.PostProcessing.PostProcessingComponentCommandBuffer`1::.ctor()
// 0x0000010C System.Void UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1::Prepare(UnityEngine.Material)
// 0x0000010D System.Void UnityEngine.PostProcessing.PostProcessingComponentRenderTexture`1::.ctor()
// 0x0000010E System.Boolean UnityEngine.PostProcessing.PostProcessingContext::get_interrupted()
extern void PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F (void);
// 0x0000010F System.Void UnityEngine.PostProcessing.PostProcessingContext::set_interrupted(System.Boolean)
extern void PostProcessingContext_set_interrupted_m49B5E6F087E28EDD810507B98AC782525B3E0D9E (void);
// 0x00000110 System.Void UnityEngine.PostProcessing.PostProcessingContext::Interrupt()
extern void PostProcessingContext_Interrupt_mE079F46BCEDB8D2A9312E99718CE6C29C328D788 (void);
// 0x00000111 UnityEngine.PostProcessing.PostProcessingContext UnityEngine.PostProcessing.PostProcessingContext::Reset()
extern void PostProcessingContext_Reset_m6715107A49BBB86B5B638808114670265B43EA17 (void);
// 0x00000112 System.Boolean UnityEngine.PostProcessing.PostProcessingContext::get_isGBufferAvailable()
extern void PostProcessingContext_get_isGBufferAvailable_mC09D6470576F02B9AEB16401F649A99E9148CF11 (void);
// 0x00000113 System.Boolean UnityEngine.PostProcessing.PostProcessingContext::get_isHdr()
extern void PostProcessingContext_get_isHdr_m4B5F1AE2F5A5DF6AA3BDA14C7EC48D64C5AE55CB (void);
// 0x00000114 System.Int32 UnityEngine.PostProcessing.PostProcessingContext::get_width()
extern void PostProcessingContext_get_width_m4FAF966400473CC9916F061098C91333191DB4D1 (void);
// 0x00000115 System.Int32 UnityEngine.PostProcessing.PostProcessingContext::get_height()
extern void PostProcessingContext_get_height_m846FF38F76BD6BA8B6384C70ED134BD01E43BDE2 (void);
// 0x00000116 UnityEngine.Rect UnityEngine.PostProcessing.PostProcessingContext::get_viewport()
extern void PostProcessingContext_get_viewport_mCED91DA77E2AACCF2B70F1F712DADF5EADDDC58F (void);
// 0x00000117 System.Void UnityEngine.PostProcessing.PostProcessingContext::.ctor()
extern void PostProcessingContext__ctor_m5B7385F53C874D3C245CC8E8D5ADCB8CF74E9B25 (void);
// 0x00000118 System.Boolean UnityEngine.PostProcessing.PostProcessingModel::get_enabled()
extern void PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885 (void);
// 0x00000119 System.Void UnityEngine.PostProcessing.PostProcessingModel::set_enabled(System.Boolean)
extern void PostProcessingModel_set_enabled_m8BBC51EA5A7FB95051AF25FC3C8FA1DD79594C37 (void);
// 0x0000011A System.Void UnityEngine.PostProcessing.PostProcessingModel::Reset()
// 0x0000011B System.Void UnityEngine.PostProcessing.PostProcessingModel::OnValidate()
extern void PostProcessingModel_OnValidate_mD71A3DC68235ADB4482A6A9F5C85477750A7AD0D (void);
// 0x0000011C System.Void UnityEngine.PostProcessing.PostProcessingModel::.ctor()
extern void PostProcessingModel__ctor_m6C73498EA865E867DFAC27A88B6D1F597CAAAC77 (void);
// 0x0000011D System.Void UnityEngine.PostProcessing.PostProcessingProfile::.ctor()
extern void PostProcessingProfile__ctor_m31DA1F3AA712B6B80D8D58DCBAA8474100156DCE (void);
// 0x0000011E System.Void UnityEngine.PostProcessing.ColorGradingCurve::.ctor(UnityEngine.AnimationCurve,System.Single,System.Boolean,UnityEngine.Vector2)
extern void ColorGradingCurve__ctor_m7A97F58ABE03C89193D1ED5D1882C6D99F020E1E (void);
// 0x0000011F System.Void UnityEngine.PostProcessing.ColorGradingCurve::Cache()
extern void ColorGradingCurve_Cache_mE2681BA1052637190D45034BE4B4D5AE92254434 (void);
// 0x00000120 System.Single UnityEngine.PostProcessing.ColorGradingCurve::Evaluate(System.Single)
extern void ColorGradingCurve_Evaluate_m4F55025ACE1BCD23F8DA0387885C18747F7AE6E8 (void);
// 0x00000121 System.Boolean UnityEngine.PostProcessing.GraphicsUtils::get_isLinearColorSpace()
extern void GraphicsUtils_get_isLinearColorSpace_m893817B8B3CE926E73C5A87AB818D90C4CAD0306 (void);
// 0x00000122 System.Boolean UnityEngine.PostProcessing.GraphicsUtils::get_supportsDX11()
extern void GraphicsUtils_get_supportsDX11_m68C79F95A5FBED0A51EC9E919D44AB3646F680EA (void);
// 0x00000123 UnityEngine.Texture2D UnityEngine.PostProcessing.GraphicsUtils::get_whiteTexture()
extern void GraphicsUtils_get_whiteTexture_mC3334B4B82001AA13E16180EBE587F7181FCF76D (void);
// 0x00000124 UnityEngine.Mesh UnityEngine.PostProcessing.GraphicsUtils::get_quad()
extern void GraphicsUtils_get_quad_m6B749345AD23DF051A0854E1A7DC5D145ED6D246 (void);
// 0x00000125 System.Void UnityEngine.PostProcessing.GraphicsUtils::Blit(UnityEngine.Material,System.Int32)
extern void GraphicsUtils_Blit_mCC20B0EA9CB3F3835FF69005EAC7A68F3336FA9F (void);
// 0x00000126 System.Void UnityEngine.PostProcessing.GraphicsUtils::ClearAndBlit(UnityEngine.Texture,UnityEngine.RenderTexture,UnityEngine.Material,System.Int32,System.Boolean,System.Boolean)
extern void GraphicsUtils_ClearAndBlit_m2AAADE156F34D3F76D8283003FBC86D0AEFDBACE (void);
// 0x00000127 System.Void UnityEngine.PostProcessing.GraphicsUtils::Destroy(UnityEngine.Object)
extern void GraphicsUtils_Destroy_m32BE15B5C9C7E49A6F396AB307260A8BC3B5A6EA (void);
// 0x00000128 System.Void UnityEngine.PostProcessing.GraphicsUtils::Dispose()
extern void GraphicsUtils_Dispose_mF5E83C9144A7F81E8F5BD34431E21B4D3B52B320 (void);
// 0x00000129 System.Void UnityEngine.PostProcessing.MaterialFactory::.ctor()
extern void MaterialFactory__ctor_m4349A2881D8319607ED9AA88B1BB9B05968B7020 (void);
// 0x0000012A UnityEngine.Material UnityEngine.PostProcessing.MaterialFactory::Get(System.String)
extern void MaterialFactory_Get_m9F25A1B3767C0E115F281F568051C19A5621AFB9 (void);
// 0x0000012B System.Void UnityEngine.PostProcessing.MaterialFactory::Dispose()
extern void MaterialFactory_Dispose_mC7A897962122085E3867E048431AA523BAB3C743 (void);
// 0x0000012C System.Void UnityEngine.PostProcessing.RenderTextureFactory::.ctor()
extern void RenderTextureFactory__ctor_mBC89C8B154571E51E112FEED9B669AC8DB508C45 (void);
// 0x0000012D UnityEngine.RenderTexture UnityEngine.PostProcessing.RenderTextureFactory::Get(UnityEngine.RenderTexture)
extern void RenderTextureFactory_Get_m60A31CA2C3799F5C48C188ABD53FAB5C4AF299B3 (void);
// 0x0000012E UnityEngine.RenderTexture UnityEngine.PostProcessing.RenderTextureFactory::Get(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat,UnityEngine.RenderTextureReadWrite,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,System.String)
extern void RenderTextureFactory_Get_m6360C458AC385DA8CD4482470A6448D8813F20A6 (void);
// 0x0000012F System.Void UnityEngine.PostProcessing.RenderTextureFactory::Release(UnityEngine.RenderTexture)
extern void RenderTextureFactory_Release_m68EF13C168000B02D1B73D6D3006905DFA34819B (void);
// 0x00000130 System.Void UnityEngine.PostProcessing.RenderTextureFactory::ReleaseAll()
extern void RenderTextureFactory_ReleaseAll_m45D549D5F66760B3C9DF4EE4C2F02CC0D8AE644A (void);
// 0x00000131 System.Void UnityEngine.PostProcessing.RenderTextureFactory::Dispose()
extern void RenderTextureFactory_Dispose_m157D256FDBA742A0F3D513AEA563E3CF183E713B (void);
// 0x00000132 System.Void UnityEngine.PostProcessing.AmbientOcclusionComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mC713CDFE19841DDF547AA4CBC0617FD5C1C04263 (void);
// 0x00000133 System.Void UnityEngine.PostProcessing.BloomComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mA62A9DF34E30157CB2C7E0194F840F052CEE8EAA (void);
// 0x00000134 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mD87D137D0F5BF1412FDEB8D9B27539A7734B93F9 (void);
// 0x00000135 UnityEngine.Mesh UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::get_mesh()
extern void ArrowArray_get_mesh_m2FEDA26A5AF1A4EB45500B48D90C2A77143EC2A5 (void);
// 0x00000136 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::set_mesh(UnityEngine.Mesh)
extern void ArrowArray_set_mesh_m0FED37676A310829555143967E29C6CCF6589274 (void);
// 0x00000137 System.Int32 UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::get_columnCount()
extern void ArrowArray_get_columnCount_m322CB9227C6F92D5B85F51D1E76BF9FCA878CF6F (void);
// 0x00000138 System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::set_columnCount(System.Int32)
extern void ArrowArray_set_columnCount_m5EBCBDA6CD7211BA1EA197DDC20365BDD75B9147 (void);
// 0x00000139 System.Int32 UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::get_rowCount()
extern void ArrowArray_get_rowCount_mDA2E4D8A35BD13A0080E40A9A95C330F6A2EE0E0 (void);
// 0x0000013A System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::set_rowCount(System.Int32)
extern void ArrowArray_set_rowCount_mEA4B53854D630F0FC2CDBAC9711527CFADCD40B7 (void);
// 0x0000013B System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::BuildMesh(System.Int32,System.Int32)
extern void ArrowArray_BuildMesh_mD8EE3BFD74DFFFB16F66A780C9CDCCD463ECB4BD (void);
// 0x0000013C System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::Release()
extern void ArrowArray_Release_m468831C28553A7D8061AE5A0B521BCA42BC2F3C7 (void);
// 0x0000013D System.Void UnityEngine.PostProcessing.BuiltinDebugViewsComponent_ArrowArray::.ctor()
extern void ArrowArray__ctor_mC31D6A2884B910FD3007BF4EF036BF1E3EC84503 (void);
// 0x0000013E System.Void UnityEngine.PostProcessing.ChromaticAberrationComponent_Uniforms::.cctor()
extern void Uniforms__cctor_m1A4F94C413A74873F53A1DBF41203964C333186E (void);
// 0x0000013F System.Void UnityEngine.PostProcessing.ColorGradingComponent_Uniforms::.cctor()
extern void Uniforms__cctor_m5EE7940F859512E0D626B64EE411D394433E8B75 (void);
// 0x00000140 System.Void UnityEngine.PostProcessing.DepthOfFieldComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mDCFD0EA62A65DF6DF00BE11F8CAB4FCCBD7A13DC (void);
// 0x00000141 System.Void UnityEngine.PostProcessing.DitheringComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mEF0B1DF95C7597AAE3E734B58C95C5B7DD55547A (void);
// 0x00000142 System.Void UnityEngine.PostProcessing.EyeAdaptationComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mCD39EEF0420035879C558A506C0FE77E00CCE22D (void);
// 0x00000143 System.Void UnityEngine.PostProcessing.FogComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mAB9524CA45FFF53FC50B59A1C5637146EE370405 (void);
// 0x00000144 System.Void UnityEngine.PostProcessing.FxaaComponent_Uniforms::.cctor()
extern void Uniforms__cctor_m3ACDDB63079CB403F19D61A0A96A12573F568312 (void);
// 0x00000145 System.Void UnityEngine.PostProcessing.GrainComponent_Uniforms::.cctor()
extern void Uniforms__cctor_m181AA37D964E0113FCE926E75B4A3C7A510F2F98 (void);
// 0x00000146 System.Void UnityEngine.PostProcessing.MotionBlurComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mADC5732B89158E0AD55B29B6E9C129738F3A2B4A (void);
// 0x00000147 System.Void UnityEngine.PostProcessing.MotionBlurComponent_ReconstructionFilter::.ctor()
extern void ReconstructionFilter__ctor_mFD306D50DD310004AB5F506EADCF325B0937DB18 (void);
// 0x00000148 System.Void UnityEngine.PostProcessing.MotionBlurComponent_ReconstructionFilter::CheckTextureFormatSupport()
extern void ReconstructionFilter_CheckTextureFormatSupport_m5BAE17550AA500EB1DA582B6B6032D71FD70E1CD (void);
// 0x00000149 System.Boolean UnityEngine.PostProcessing.MotionBlurComponent_ReconstructionFilter::IsSupported()
extern void ReconstructionFilter_IsSupported_m37BB8C07D34B96DC5246E67EBE453ED216E8C176 (void);
// 0x0000014A System.Void UnityEngine.PostProcessing.MotionBlurComponent_ReconstructionFilter::ProcessImage(UnityEngine.PostProcessing.PostProcessingContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.PostProcessing.MotionBlurModel_Settings&,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material)
extern void ReconstructionFilter_ProcessImage_m43E3DB760FCB6769EFD4ABA78D0BB5EA7AE95D8F (void);
// 0x0000014B System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::.ctor()
extern void FrameBlendingFilter__ctor_mF0603488404518BA719F3DC2C3DE3086781097BE (void);
// 0x0000014C System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::Dispose()
extern void FrameBlendingFilter_Dispose_mDFB3481B39ED1BC881C6E7A9ABB7C279E3A07339 (void);
// 0x0000014D System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::PushFrame(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,System.Int32,UnityEngine.Material)
extern void FrameBlendingFilter_PushFrame_m8D30426B960859C77503A34DEB6C34AF1BEAB2F8 (void);
// 0x0000014E System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::BlendFrames(UnityEngine.Rendering.CommandBuffer,System.Single,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material)
extern void FrameBlendingFilter_BlendFrames_mEDFE6BAEF67327185FA062B887A8AF6A0087B93F (void);
// 0x0000014F System.Boolean UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::CheckSupportCompression()
extern void FrameBlendingFilter_CheckSupportCompression_mB650DD4D10F2C4D179F28CA3FCA216C8F2BF545D (void);
// 0x00000150 UnityEngine.RenderTextureFormat UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::GetPreferredRenderTextureFormat()
extern void FrameBlendingFilter_GetPreferredRenderTextureFormat_m1A74C8BD244DBA4002DDFA621E2D8B61627F83F8 (void);
// 0x00000151 UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter_Frame UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter::GetFrameRelative(System.Int32)
extern void FrameBlendingFilter_GetFrameRelative_m471D9972BD5D46529E9C8367F26234EC3E6D9565 (void);
// 0x00000152 System.Void UnityEngine.PostProcessing.ScreenSpaceReflectionComponent_Uniforms::.cctor()
extern void Uniforms__cctor_m14B952A88249426EC2DEE575D407895ADE030AA3 (void);
// 0x00000153 System.Void UnityEngine.PostProcessing.TaaComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mE35E923121972C1045D2185D98C19090D3748F58 (void);
// 0x00000154 System.Void UnityEngine.PostProcessing.UserLutComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mA2663CDFEC7B2ED77C78A899EC5CC903EC061BE2 (void);
// 0x00000155 System.Void UnityEngine.PostProcessing.VignetteComponent_Uniforms::.cctor()
extern void Uniforms__cctor_mE896A281C010674DD689010BE6C91D3438899EA3 (void);
// 0x00000156 UnityEngine.PostProcessing.AmbientOcclusionModel_Settings UnityEngine.PostProcessing.AmbientOcclusionModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m790BA9D65EDEA2C144DCFA9144D38071F2220BBA (void);
// 0x00000157 System.Void UnityEngine.PostProcessing.AntialiasingModel_FxaaQualitySettings::.cctor()
extern void FxaaQualitySettings__cctor_m88A2C5F3355258E247988B70690583A2E12F8D5B (void);
// 0x00000158 System.Void UnityEngine.PostProcessing.AntialiasingModel_FxaaConsoleSettings::.cctor()
extern void FxaaConsoleSettings__cctor_m8CBE5237BF44F8CBA2A85E5B2B1E2DEC4B3E83EF (void);
// 0x00000159 UnityEngine.PostProcessing.AntialiasingModel_FxaaSettings UnityEngine.PostProcessing.AntialiasingModel_FxaaSettings::get_defaultSettings()
extern void FxaaSettings_get_defaultSettings_mCA0F59291814B898CB55A5CFD38D853615A28537 (void);
// 0x0000015A UnityEngine.PostProcessing.AntialiasingModel_TaaSettings UnityEngine.PostProcessing.AntialiasingModel_TaaSettings::get_defaultSettings()
extern void TaaSettings_get_defaultSettings_m98B736C7C815ABD628506A59D2B5CABE28EEB8A0 (void);
// 0x0000015B UnityEngine.PostProcessing.AntialiasingModel_Settings UnityEngine.PostProcessing.AntialiasingModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m2D6C780FB5483B1B7159C259B65F8049E24701B0 (void);
// 0x0000015C System.Void UnityEngine.PostProcessing.BloomModel_BloomSettings::set_thresholdLinear(System.Single)
extern void BloomSettings_set_thresholdLinear_m110754AE2464BC3D1436D6E0D482F4CF42A63B32_AdjustorThunk (void);
// 0x0000015D System.Single UnityEngine.PostProcessing.BloomModel_BloomSettings::get_thresholdLinear()
extern void BloomSettings_get_thresholdLinear_m53F5754536E0777F50F791F207844E986DC18AF7_AdjustorThunk (void);
// 0x0000015E UnityEngine.PostProcessing.BloomModel_BloomSettings UnityEngine.PostProcessing.BloomModel_BloomSettings::get_defaultSettings()
extern void BloomSettings_get_defaultSettings_m541422CC17F842C57AE55A224BF3C53C768E1785 (void);
// 0x0000015F UnityEngine.PostProcessing.BloomModel_LensDirtSettings UnityEngine.PostProcessing.BloomModel_LensDirtSettings::get_defaultSettings()
extern void LensDirtSettings_get_defaultSettings_mEBABB0843318E82DFF53ABAAEBD74A981569EAC3 (void);
// 0x00000160 UnityEngine.PostProcessing.BloomModel_Settings UnityEngine.PostProcessing.BloomModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_mC8DEF8E5420A7AC375FF5164D2A11C6BA9D23A2B (void);
// 0x00000161 UnityEngine.PostProcessing.BuiltinDebugViewsModel_DepthSettings UnityEngine.PostProcessing.BuiltinDebugViewsModel_DepthSettings::get_defaultSettings()
extern void DepthSettings_get_defaultSettings_m740227F0138C1604D884468ADE28C1E06A0A98FD (void);
// 0x00000162 UnityEngine.PostProcessing.BuiltinDebugViewsModel_MotionVectorsSettings UnityEngine.PostProcessing.BuiltinDebugViewsModel_MotionVectorsSettings::get_defaultSettings()
extern void MotionVectorsSettings_get_defaultSettings_mD0F08A9A94F262C5AAC437C044E78FA10485CE72 (void);
// 0x00000163 UnityEngine.PostProcessing.BuiltinDebugViewsModel_Settings UnityEngine.PostProcessing.BuiltinDebugViewsModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m75D16BE9820DC3F6A4B25D69DE521C35230CFFFD (void);
// 0x00000164 UnityEngine.PostProcessing.ChromaticAberrationModel_Settings UnityEngine.PostProcessing.ChromaticAberrationModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m1CF1CC3AFCD0C0CD5FE9F2C4D8042844ECA105A8 (void);
// 0x00000165 UnityEngine.PostProcessing.ColorGradingModel_TonemappingSettings UnityEngine.PostProcessing.ColorGradingModel_TonemappingSettings::get_defaultSettings()
extern void TonemappingSettings_get_defaultSettings_mC88317C18514F713304598A541DD0248ED338CB6 (void);
// 0x00000166 UnityEngine.PostProcessing.ColorGradingModel_BasicSettings UnityEngine.PostProcessing.ColorGradingModel_BasicSettings::get_defaultSettings()
extern void BasicSettings_get_defaultSettings_mF905204299C43D709646CB05B405D38A6A6F4DD8 (void);
// 0x00000167 UnityEngine.PostProcessing.ColorGradingModel_ChannelMixerSettings UnityEngine.PostProcessing.ColorGradingModel_ChannelMixerSettings::get_defaultSettings()
extern void ChannelMixerSettings_get_defaultSettings_mB4CD0904ACCD19543C1E3305EB479EF1C68ADD6D (void);
// 0x00000168 UnityEngine.PostProcessing.ColorGradingModel_LogWheelsSettings UnityEngine.PostProcessing.ColorGradingModel_LogWheelsSettings::get_defaultSettings()
extern void LogWheelsSettings_get_defaultSettings_m5DCE15C9BAB587096E9CD29209EE5A3115F663D4 (void);
// 0x00000169 UnityEngine.PostProcessing.ColorGradingModel_LinearWheelsSettings UnityEngine.PostProcessing.ColorGradingModel_LinearWheelsSettings::get_defaultSettings()
extern void LinearWheelsSettings_get_defaultSettings_mC05B5B5123222C9800E3E59F00620B9F4BE37AE4 (void);
// 0x0000016A UnityEngine.PostProcessing.ColorGradingModel_ColorWheelsSettings UnityEngine.PostProcessing.ColorGradingModel_ColorWheelsSettings::get_defaultSettings()
extern void ColorWheelsSettings_get_defaultSettings_m37036621FD5F5BE60ACC53910CA2EBB0009973CA (void);
// 0x0000016B UnityEngine.PostProcessing.ColorGradingModel_CurvesSettings UnityEngine.PostProcessing.ColorGradingModel_CurvesSettings::get_defaultSettings()
extern void CurvesSettings_get_defaultSettings_m1BE81E4DFBB87BDEB9B0C81D6934FA518837B361 (void);
// 0x0000016C UnityEngine.PostProcessing.ColorGradingModel_Settings UnityEngine.PostProcessing.ColorGradingModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_mA905C37C111AA5E39311404A909196136C50FC76 (void);
// 0x0000016D UnityEngine.PostProcessing.DepthOfFieldModel_Settings UnityEngine.PostProcessing.DepthOfFieldModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m379831F7B7CF92CA85486AEFFCA53BC093DDB796 (void);
// 0x0000016E UnityEngine.PostProcessing.DitheringModel_Settings UnityEngine.PostProcessing.DitheringModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_mDE670379448F42DFB728D2F8F3D3DE98B8941D0A (void);
// 0x0000016F UnityEngine.PostProcessing.EyeAdaptationModel_Settings UnityEngine.PostProcessing.EyeAdaptationModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m2FDDC1FB7081FAE62C40B110267F4C3D0545985F (void);
// 0x00000170 UnityEngine.PostProcessing.FogModel_Settings UnityEngine.PostProcessing.FogModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m7A0B383860B9A801075380E5F797C5D9AF760939 (void);
// 0x00000171 UnityEngine.PostProcessing.GrainModel_Settings UnityEngine.PostProcessing.GrainModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m9159627217232A842D921250845183A2A398081B (void);
// 0x00000172 UnityEngine.PostProcessing.MotionBlurModel_Settings UnityEngine.PostProcessing.MotionBlurModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m406A0B3CD5A263EB5BC1FE05F2DDDF8AF82404BB (void);
// 0x00000173 UnityEngine.PostProcessing.ScreenSpaceReflectionModel_Settings UnityEngine.PostProcessing.ScreenSpaceReflectionModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m4476B15B5C3BD8033730CF2D9B986FD67BF9523C (void);
// 0x00000174 UnityEngine.PostProcessing.UserLutModel_Settings UnityEngine.PostProcessing.UserLutModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B (void);
// 0x00000175 UnityEngine.PostProcessing.VignetteModel_Settings UnityEngine.PostProcessing.VignetteModel_Settings::get_defaultSettings()
extern void Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C (void);
// 0x00000176 System.Single UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter_Frame::CalculateWeight(System.Single,System.Single)
extern void Frame_CalculateWeight_m0D77630E6D4279DD16600C805650520D4DD01A33_AdjustorThunk (void);
// 0x00000177 System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter_Frame::Release()
extern void Frame_Release_m3FE08AF74AEB729A2A934FBD5F6844D949E0D808_AdjustorThunk (void);
// 0x00000178 System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter_Frame::MakeRecord(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,System.Int32,UnityEngine.Material)
extern void Frame_MakeRecord_m4643EE697F001944666AEB7CEA9060840A22B6FD_AdjustorThunk (void);
// 0x00000179 System.Void UnityEngine.PostProcessing.MotionBlurComponent_FrameBlendingFilter_Frame::MakeRecordRaw(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,System.Int32,UnityEngine.RenderTextureFormat)
extern void Frame_MakeRecordRaw_m86A8B06A27C8677059E77C8B48786C1688DC014C_AdjustorThunk (void);
static Il2CppMethodPointer s_methodPointers[377] = 
{
	FreeCam_Start_mF5B1F688F6C531E10E6DFC2E94A9E8FEB651FF41,
	FreeCam_Update_m9E408EF9883951D3C1CE549A51144A3ADF5CAB95,
	FreeCam__ctor_m9C4332750C154E49B7BE864188DA948AF94422E7,
	ScrollUVWater_Start_m8B0296588EC6749DF1D8C3E4073A7066A52EF3BE,
	ScrollUVWater_Update_m197A72FD435FA0C9131750CEC63E4C0AB8E8C04D,
	ScrollUVWater__ctor_m52B05CDF5FE1FE547F0CD41A12F42D7D70CC1999,
	EditorMouseLook__ctor_mB690A47F1EA4A1DAB8AF0EA7B902EF2911754C7C,
	NvrAdvancedWalk_Start_mD10D9A64BBBF2E3C063D2662CD138F5502696D7B,
	NvrAdvancedWalk_Update_m7BD3A660E23C8CA63522660D0B78BD25F9596C77,
	NvrAdvancedWalk_AllowedToMove_m7FC6764ECDA7E2AB4860196EE9EFA88F9F04D0F2,
	NvrAdvancedWalk__ctor_m31AB362A2CA84C7008F45387A328C99BEA478D09,
	NvrAutofly_Start_mC9DA30A17A97440B4BC78174CD20CBC9A462D848,
	NvrAutofly_Update_mFADA15C4BA79A728BC0219517EAA32A523130BE0,
	NvrAutofly__ctor_mD11B80F9C93930F8434902EE86F68D2ADB8C102C,
	NvrAutowalk_Start_m7E552E80F0C69E506D8EEEAF856E4C7F8CD1D8BD,
	NvrAutowalk_Update_m54AE367C1D7DF21AF3AC8FA9C5509A1A69E06541,
	NvrAutowalk__ctor_m71F63B8E8EC26AB2DF14E5AC8CA99588625ABB1C,
	NvrBluetoothController_Start_m0159793D111B52111DA6FB63E1B784C25C0C1B7B,
	NvrBluetoothController_Update_m0934D8FC30561F249F5399DFFB9B0B3D053A7BBC,
	NvrBluetoothController__ctor_m6219198542880799D4341BEBB8FFD3AA91570B55,
	NvrLookWalk_Start_m006379042FB6EE4A36C89B2B0EE0F5992C27C205,
	NvrLookWalk_Update_m03400A24A1059B11C1DF3A91EAACD56DF3EDA3F1,
	NvrLookWalk__ctor_m04F90ED3BD9FF9A06F0E82F9D41DF4E5B3630C13,
	NvrSimpleGazeInputModule_Start_m15580CF657A4AD1B602B06165C6FA7C4A8497DC4,
	NvrSimpleGazeInputModule_Process_m8776C499844F78B4C1144FBCE07761B24EC2B34B,
	NvrSimpleGazeInputModule_HandleLook_mF3C621197E88CB58D01C1077B5AABFE2619041C2,
	NvrSimpleGazeInputModule_HandleSelection_m58F13FC6CD5B39F82E277426B198AA470B1A7BFF,
	NvrSimpleGazeInputModule_SetCenterOfScreen_m97989109D8275EE663FFB7E2200CFEB1AF042F5E,
	NvrSimpleGazeInputModule__ctor_m730DA9A22205333CA7DC861C89E4D0BAB3F08AEF,
	NvrWalkableSurface_Start_m36E40179C4D8393F1B2C1C745EA0F35BF12DBD49,
	NvrWalkableSurface_OnPointerEnter_m33327A49D2834C0A57B8B2EC9A32B963178713CB,
	NvrWalkableSurface_OnPointerExit_m7FF44F2913C0D46BD4E01B6758807FBB8C2FE64A,
	NvrWalkableSurface_OnPointerClick_m8F759B049EEC64BEC29E688A7C07B5BC28EB697A,
	NvrWalkableSurface_OnPointerUp_mA7C329150767D36CE9FE52D0CB2159688D64A6FF,
	NvrWalkableSurface_OnPointerDown_mB5D5AF84B208D42EA322F45CA63A69B03751697F,
	NvrWalkableSurface__ctor_m0455B2198063FF80242162B3681A8982DDE9265A,
	NvrWalkableSurface_U3CStartU3Eb__5_0_mAF11A8404AD088B8F6BB718D78C7599D00FD072F,
	NvrWalkableSurface_U3CStartU3Eb__5_1_mF5AFA4A48FDEF3C226A2EBBFAAFFD220F0773B3A,
	NvrWalkableSurface_U3CStartU3Eb__5_2_m268BDFAD1037EC65E4FB856B961D0FAEB7AD61D8,
	NvrWalkableSurface_U3CStartU3Eb__5_3_m2A2EFCC2DB472DDFB3A2C5372E9540035E713D8E,
	NvrWalkableSurface_U3CStartU3Eb__5_4_mBB71C01C1F5E232BA98E179C0393C98B9FEC4DCE,
	NvrWaypointData__ctor_m7877B5426EACA3CDDFB0DD792F514D1EB322A609,
	GetSetAttribute__ctor_mB78D2364742AEFCF07D8F290356263F033EE6A61,
	MinAttribute__ctor_m97852EBB1F8E9CF4F4164D0C1810B3D19238D6C2,
	TrackballAttribute__ctor_m29DE2CEE0A7467BE4F578AC7B762C94A1430C649,
	TrackballGroupAttribute__ctor_m1B6EEB0B9F912A14F405EDF62A104E401E9FADE7,
	AmbientOcclusionComponent_get_occlusionSource_m70F9BD953816398C5D53C562E68021D978636874,
	AmbientOcclusionComponent_get_ambientOnlySupported_m73040AB2E44029629F405012A458155725A5F98B,
	AmbientOcclusionComponent_get_active_mB2330BF78D5848902B4510C26053240CCF524B8C,
	AmbientOcclusionComponent_GetCameraFlags_mFAE738A41FD764C3793F307BD8832CD05EEAF0BE,
	AmbientOcclusionComponent_GetName_m86DDB268262D55138E46D438FFB78E83102A938E,
	AmbientOcclusionComponent_GetCameraEvent_m07477337350B2F55AFC5CE499370455867C3968B,
	AmbientOcclusionComponent_PopulateCommandBuffer_m89E5BF7E24906A47DA1D948FE2D9352FF4AFF125,
	AmbientOcclusionComponent__ctor_mE1A80D750AA95DB83F91B808D4D361BE303C572F,
	BloomComponent_get_active_m0B60B922D6CF1835EE866C9804003D106ABC9360,
	BloomComponent_Prepare_m84B367E0B792227B7C2259E00797026C101B6B20,
	BloomComponent__ctor_mBD2FE039C08EA1175AF172A1D50CE9B664ECE0D2,
	BuiltinDebugViewsComponent_get_active_mA9EB56F0478526BFC269AD4C08B82AA144C6B843,
	BuiltinDebugViewsComponent_GetCameraFlags_m4571BA49F5063EA22429FA7BA1B5E8E9191C52AE,
	BuiltinDebugViewsComponent_GetCameraEvent_m631353AA2D227CE3CB98548856466B3742B27BE1,
	BuiltinDebugViewsComponent_GetName_m0DC6AF116D118969CC80AE06144970BCBFFB8861,
	BuiltinDebugViewsComponent_PopulateCommandBuffer_mE290FCC45E152D6616C08C1DA98F1ADA1F5547E1,
	BuiltinDebugViewsComponent_DepthPass_m380EF17F1EE1B26DD619ADCC5E973E4F821B5916,
	BuiltinDebugViewsComponent_DepthNormalsPass_m8C1715B0F76ED17B41E327F5CE4E138E15913C7A,
	BuiltinDebugViewsComponent_MotionVectorsPass_mD488C6C61E8FCB9EA35CD621B1CB9975EF28DDE6,
	BuiltinDebugViewsComponent_PrepareArrows_m04C364DCE5177F0C57BD8CEA38EFF5B99653EAD5,
	BuiltinDebugViewsComponent_OnDisable_m86100E0F48531E95E4C9473D7870BBC92948D84F,
	BuiltinDebugViewsComponent__ctor_mE356ADF2CDB4CBB8D435659AB0F4191C117333A4,
	ChromaticAberrationComponent_get_active_m7D368F73DC5ACA35593DE90E00C391502F9885EB,
	ChromaticAberrationComponent_OnDisable_m68D924D9161504019E6FC5FF1E66361C0E1BB88D,
	ChromaticAberrationComponent_Prepare_m632672B73986E3CDA4D506F3FC315BF3C82F8CCC,
	ChromaticAberrationComponent__ctor_m92C689EEF99E2909C854F791FA7AC62BD3E7CBE0,
	ColorGradingComponent_get_active_m76FB6862F31EDBB17C36902FE411671FEAB64F13,
	ColorGradingComponent_StandardIlluminantY_mA64FF93EDC7E3CF1257836F19A3F6D92AC8FFC04,
	ColorGradingComponent_CIExyToLMS_m64212E8FC2D7034BBC11308EA91194B5D5ACC260,
	ColorGradingComponent_CalculateColorBalance_mA465E684D3E727DC86F1896520369E1990253488,
	ColorGradingComponent_NormalizeColor_m5E0660CCF0D8DB1A0D2C7E359D8DB4A9F7C2F4F0,
	ColorGradingComponent_ClampVector_m6DF366595D54DE1E58DA6839653BAD38FA68536D,
	ColorGradingComponent_GetLiftValue_m85B45C45F1113D2493E8DE775CD78062AD66E14A,
	ColorGradingComponent_GetGammaValue_mDD279576E7A546613F9D3E4D0D7205539B5736DE,
	ColorGradingComponent_GetGainValue_m9CFCD1A6F31FA01BDCE8781AB60A84EC70664249,
	ColorGradingComponent_CalculateLiftGammaGain_m55F6078CA1BE1A0150422645F04D6C25429F32B5,
	ColorGradingComponent_GetSlopeValue_m0B47DB5B6B4F016B2929174F11A00AE149C4B1A8,
	ColorGradingComponent_GetPowerValue_m20CF0604640F55A2C08BD7D91746DFF338E9B125,
	ColorGradingComponent_GetOffsetValue_m12B953F4A87E9B7A0F07CD3F30430A63E2D87D84,
	ColorGradingComponent_CalculateSlopePowerOffset_m6AACCEC175AE207B98F1BCD93E7C9DC6BEAF7163,
	ColorGradingComponent_GetCurveFormat_m9A10A892BE6D77F8B6214E2D2CAEDF2E49230A4B,
	ColorGradingComponent_GetCurveTexture_m1DABCAA3214DEABCE23281F4A8A090E46B08AC79,
	ColorGradingComponent_IsLogLutValid_m606AC9EB30D7183147900B3A846DFD128C1B458F,
	ColorGradingComponent_GetLutFormat_m867EA4444CF8FBD12A2F2B6F62881D9875C999A4,
	ColorGradingComponent_GenerateLut_m043651CED856228F73388E50A029E0EA8774D384,
	ColorGradingComponent_Prepare_mA1E712E3432AC653D6E2E0A7E802BC689FFA9C09,
	ColorGradingComponent_OnGUI_m5739ED4E204A8D56BED83DC3A9A562FDFC1F5F3B,
	ColorGradingComponent_OnDisable_m4D95AE6438146DF8F5A9020CEDD6B30161ABB69A,
	ColorGradingComponent__ctor_m9DF6AF00D9D6A8FDFB05424D98CD08E5BDCF7B33,
	DepthOfFieldComponent_get_active_m8C900A01927CFB07C0F74E4756CA6CA7BD2C3E9C,
	DepthOfFieldComponent_GetCameraFlags_mA37E541AF33930DC281FB2FA29604BAA41BCD1B5,
	DepthOfFieldComponent_CalculateFocalLength_mBCF186E2B4066FF4F1813A3D1200298CC7F1C9B9,
	DepthOfFieldComponent_CalculateMaxCoCRadius_m1B17A8072B986F3E67BF0EA2FBAE4A63B3C8188D,
	DepthOfFieldComponent_CheckHistory_m54CD5D5E241F656272A07CF8C93312380AF39539,
	DepthOfFieldComponent_SelectFormat_mE40E7364B96E18AE75C6C090384EF2034F195666,
	DepthOfFieldComponent_Prepare_m4763AEAAB0FD35F56899E607BCE09023A0B58807,
	DepthOfFieldComponent_OnDisable_m923BB095D604D4C027117CC9195569EE4B41875A,
	DepthOfFieldComponent__ctor_mCD94663F108DD3B104014AB90CC47B8B5F909B55,
	DitheringComponent_get_active_mC16AFBB316053FFD221071F7F47200C253735929,
	DitheringComponent_OnDisable_m92FD815A36D869F5FE7453F6F16ED27D8E55805E,
	DitheringComponent_LoadNoiseTextures_m4866E1B9627F4E816B83B040327EB3FA0CC5B8FA,
	DitheringComponent_Prepare_m6B5B9004C89D04D2DA8431E8284E9A73FDA9319D,
	DitheringComponent__ctor_mCABC635529463FA8DAFF9CF9BFF2BC6FC2FA59DC,
	EyeAdaptationComponent_get_active_m4CE90ECB5144D6E1944621825DB792362E660704,
	EyeAdaptationComponent_ResetHistory_mD387BB29ADBD308DC62A0C58910679079C0F0A5F,
	EyeAdaptationComponent_OnEnable_mA4BDEBED24DDE8A0624EFFFA0A2DCAF2031BB643,
	EyeAdaptationComponent_OnDisable_mA2D0BE41EA1F225C26292EDB62E840E28FF2EC1A,
	EyeAdaptationComponent_GetHistogramScaleOffsetRes_mC0466D3854AB8A8E927278BD8F2A7E44388B2CE8,
	EyeAdaptationComponent_Prepare_mC53E218DB147508AB711E63B3F9978AF49E0FADB,
	EyeAdaptationComponent_OnGUI_mAAE6B381F08A15C732BD3F49400F864627D61E27,
	EyeAdaptationComponent__ctor_m9D364E527CF2EB77B524C5D7C3DEFDF1B8960EB1,
	FogComponent_get_active_m2751987EB333DB601029DE6A7591C0FA4B71C2A0,
	FogComponent_GetName_m65CDC7A0C94664738A5E0D0CC98D76493B90BC4D,
	FogComponent_GetCameraFlags_m8BF18DDF7CE926DA69601186C42035E96D41442F,
	FogComponent_GetCameraEvent_m96E10D06DBCF19690D69DB5159252601E5010121,
	FogComponent_PopulateCommandBuffer_m5FC61F3A3CDEFA1908F8E3E5307BD76CF695CE5B,
	FogComponent__ctor_mF6E4C1CDE2AEABC55C030CA3740BD7D7CFA5B447,
	FxaaComponent_get_active_m0CE0B29E2A2596758849904AE17F61951496263B,
	FxaaComponent_Render_m883201F71BD4230F307AF7477CF573CEC9BE1748,
	FxaaComponent__ctor_m656004B25A78E30A7B05466CDC7F42E9E0238DF8,
	GrainComponent_get_active_m9BA422DDF0AFD50FF7EC154E2413B2CA64EE523A,
	GrainComponent_OnDisable_mDA215CE7CE794A6CE30662F9C434006338D4E933,
	GrainComponent_Prepare_mF3F212B3B90E05C654D82C3AA9D108D8F4C3DDFF,
	GrainComponent__ctor_m86C87D37113534CF55DE3F65FC9AF08E39005632,
	MotionBlurComponent_get_reconstructionFilter_m2D51A337C27E28CD7B96FB59BB3E29C342F74F53,
	MotionBlurComponent_get_frameBlendingFilter_m9F7CDE6D8C8B53FCD822A6CFC397E00185C851F6,
	MotionBlurComponent_get_active_m215475A8D0D83731028876DC1FEEEBAE1A7E4D0E,
	MotionBlurComponent_GetName_mF6A7512CFA0392201603489852D6C6AA78F37869,
	MotionBlurComponent_ResetHistory_m3719C692707E23E5A8047A9DC9DB693E87700DB7,
	MotionBlurComponent_GetCameraFlags_m740F8262D6E7BB14747EB8581545305CF6C86233,
	MotionBlurComponent_GetCameraEvent_m52A3DFF25A1DE3875B32784EAB52487488C77745,
	MotionBlurComponent_OnEnable_mC70E688BC7993E8AEFBE2F6B7905A986D2317480,
	MotionBlurComponent_PopulateCommandBuffer_m12EC28892FAC680578A9445C00D25A003D18CD7E,
	MotionBlurComponent_OnDisable_mF6477BA3DB95D4EBCC4451ED3E24B0439F47CD9D,
	MotionBlurComponent__ctor_m0C5BD352A7650DD8C5FFD7A31635485919126074,
	ScreenSpaceReflectionComponent_GetCameraFlags_m8F442E276F930715FDEE7E1FD6EF38A5BAD0030C,
	ScreenSpaceReflectionComponent_get_active_m240BA4C4BE2A7F896AD973E16A98B52608C25E41,
	ScreenSpaceReflectionComponent_OnEnable_mBE0B89D66F04DFC19A32657EE5035F44464E6F66,
	ScreenSpaceReflectionComponent_GetName_m5594E95B415ED58AA0C94D5B2669DE3CFEC77D32,
	ScreenSpaceReflectionComponent_GetCameraEvent_mEB3D2DE975E43B91403B7839881AB3C327D9E69A,
	ScreenSpaceReflectionComponent_PopulateCommandBuffer_m174E3825418E57D7B9746DF7E32F19B64AEB4F88,
	ScreenSpaceReflectionComponent__ctor_m91D6614234484CE3D0B515348333E69CEBD9679B,
	TaaComponent_get_active_m2350E4D88BFBE23BE6EA2A1C95FBBDBA7CD4BBD1,
	TaaComponent_GetCameraFlags_m672C8089957E15DBF6FF4611D2B536284212B1C6,
	TaaComponent_get_jitterVector_mFBA80D2CE7C5056A38ECAE11DCA6004C75A3FA74,
	TaaComponent_set_jitterVector_m221CF97FE556CB4853648371AF270CE43280B369,
	TaaComponent_ResetHistory_m60D8ADC47F23D0888BCACBCDDC2A1D552BF114FD,
	TaaComponent_SetProjectionMatrix_m18AD08B73FFC2652ACAB70C825457BF0AC000656,
	TaaComponent_Render_m827CB31CC593C8D68444A639D709F17AD1B82C77,
	TaaComponent_GetHaltonValue_mBC105A450027028D9A18949FC83AC41161B91156,
	TaaComponent_GenerateRandomOffset_m451A5BB3CABF7F05C73707A19B6BA38251C808E6,
	TaaComponent_GetPerspectiveProjectionMatrix_m3C72D8F9A69268E18D503A4038AE26B315348F68,
	TaaComponent_GetOrthographicProjectionMatrix_mECEBF0642C4EF5856B8FBFFD90DC0BDA655BD9E0,
	TaaComponent_OnDisable_m7A55C79856C3587402E31968973BCBD7EBD52E6E,
	TaaComponent__ctor_m22FEB2A7DC262673228C350F29A0B3D9E8F2BC91,
	UserLutComponent_get_active_m8428217EBA5B1257B2D45C1FE4059F72C09D665B,
	UserLutComponent_Prepare_m5D8E9AEECCAB23371404DECA85CE7A3014D0AAC9,
	UserLutComponent_OnGUI_m2EB89A535861686796FE724F1826E064899C5E95,
	UserLutComponent__ctor_m6BDE4DF5D5AE258E3D1340BA1E1AC559185AE7C9,
	VignetteComponent_get_active_mF746C412DA78024BEF896F56DB353E4544A5E123,
	VignetteComponent_Prepare_m9088BC6708AC002872FADFD8681081DFA2696D1A,
	VignetteComponent__ctor_mBB15E7068E78A71AEB07345138FABB6F27E789A1,
	AmbientOcclusionModel_get_settings_m9C36453B771E7EBA4E53F11B369C1BCF20E08549,
	AmbientOcclusionModel_set_settings_m1912086621AB439FB5D5A22270486A35FF97302E,
	AmbientOcclusionModel_Reset_mB78A4BE5D2C53270CE439143B10F0960119694A5,
	AmbientOcclusionModel__ctor_mB55F4A00E65EA62DDBCB527494551BAE15E5C258,
	AntialiasingModel_get_settings_m48E6CC1150A5F6263D1FF2048AE92DDC0E6892F6,
	AntialiasingModel_set_settings_mE1C7153719F8841DE16A98AE6AD2517B06E3289D,
	AntialiasingModel_Reset_m1E897598B70AD5E5E7096A9D1C6A4D923C987913,
	AntialiasingModel__ctor_mDB833BEF202BED20ED04C0F1F6A8AEF38611BB2D,
	BloomModel_get_settings_m5275CBD5288F631F8A059DCBF58189A14E6AAFF7,
	BloomModel_set_settings_m6144736D09C7C027AFD8BC10C6E7906DCB3CAE5A,
	BloomModel_Reset_m7BEF633097291492978C6D21687B60241E790891,
	BloomModel__ctor_m4881E660097BFBF202BB4818377C3FB670F788F3,
	BuiltinDebugViewsModel_get_settings_mF3203E7D0D8E79D23A54B7501E946500E328271D,
	BuiltinDebugViewsModel_set_settings_mF472A1B9051088013CF8924D4DA13A91E3BB8AC3,
	BuiltinDebugViewsModel_get_willInterrupt_m8754446ED1973FAAC71E0549D70FBE5D7597E059,
	BuiltinDebugViewsModel_Reset_mFAFC415FD7C35572D5A2F89D0F9654F478EE5A6B,
	BuiltinDebugViewsModel_IsModeActive_m64820C64BB75E2D5308F062D90DA7341AC5394FE,
	BuiltinDebugViewsModel__ctor_mCB7371673F1AE78DF3EE1F829B26364326A5AFD6,
	ChromaticAberrationModel_get_settings_mC5B79A93335B22FE54D17B3F483FF400D90B0210,
	ChromaticAberrationModel_set_settings_mAF78E27C5C42AD5007C7932B445909C2D0ED674F,
	ChromaticAberrationModel_Reset_mDD238DA7D9984E65BD28CEBC81B150E736BC70C2,
	ChromaticAberrationModel__ctor_m842EE062AAB76F15EB58CACD2AE2DCE50272DB3D,
	ColorGradingModel_get_settings_m1AE5CBB9E2E9DB96A9F9F9B61F883CE6F7BDB1CA,
	ColorGradingModel_set_settings_mE42AD9547CD1F45F43FA6E96B5C8464232D54FE0,
	ColorGradingModel_get_isDirty_mD038D53F87E95799378AC3EF03BC85A3B90C220B,
	ColorGradingModel_set_isDirty_m98CC6398671A6D5E9AC5263AAB4D9F9EF31291D7,
	ColorGradingModel_get_bakedLut_mA985224BFA8F8272871DCA475FE22668EFD83095,
	ColorGradingModel_set_bakedLut_m6A89BD69BF4CC3EB0B464FB8112088F0C65CDCA4,
	ColorGradingModel_Reset_mC250F18368B19DBB312DF30B194FAE687DA9115D,
	ColorGradingModel_OnValidate_m9C8E0180B2E525919E113A2D4B6531AAD63D3ABD,
	ColorGradingModel__ctor_mC81EA02326D4402CF22A425F21476C807BB99662,
	DepthOfFieldModel_get_settings_mEE77E80777009ED26285FA95800061F2674A0691,
	DepthOfFieldModel_set_settings_m1F26545DE0F2839E3A5053C55CD8892236E4E983,
	DepthOfFieldModel_Reset_mC774665064B671EE232013248CE570F51DB00729,
	DepthOfFieldModel__ctor_m9B8304485D99B948E1A096D4F84CA4027F94E5BF,
	DitheringModel_get_settings_mC0B7FD09DF49DC8EE24434D27BA01E0F9B7B14CE,
	DitheringModel_set_settings_mFC15AC24B687DF396267286A865AC6C400A8FC4A,
	DitheringModel_Reset_m053FA68F846CD2DF125F67D8033C830EB335AAE9,
	DitheringModel__ctor_m982139BA8D4553156B59AD5BDDBF28F0C8269A30,
	EyeAdaptationModel_get_settings_mB1E27441C7DFE7B86A6CA0792F772633BB0FF93F,
	EyeAdaptationModel_set_settings_m40F9C581791DC0C526B25FCF62D9F340C6A59B6B,
	EyeAdaptationModel_Reset_m7AE022D22BC264608E152B3F7EBA111607548F7F,
	EyeAdaptationModel__ctor_m41A8D6FA78C56041AEA8A31758A615EA83A69A29,
	FogModel_get_settings_mCB7F6DCD80E62568148DC4248A63B839E33ED0EB,
	FogModel_set_settings_m4DF9789BB320E1F1939A9C719D05EEB494DB2F16,
	FogModel_Reset_m466762B5F9506DEE7CA3858C836B752BB4F43904,
	FogModel__ctor_mBB29F9E3F4657BCE22FB2106BEC5BEA71D6780C0,
	GrainModel_get_settings_m7DCDBBF518F83B5C7B1BDD3AA16FDEEACD730052,
	GrainModel_set_settings_mE8C8F3697DD897C330A3A62668DB86AC79694CF3,
	GrainModel_Reset_m2CF00116501BD3BBF82D78FEF31D3B97CB698AA9,
	GrainModel__ctor_m6202989714C6C665F5B32EF0B5756802B783EE19,
	MotionBlurModel_get_settings_mCF94831603AF0583B256A013888D47D41A24AC21,
	MotionBlurModel_set_settings_m600724563E8760CBC5C3BCF585B08768FD5D970C,
	MotionBlurModel_Reset_m5FEADBB97B1A1589429FB6EF728D56D2207A1148,
	MotionBlurModel__ctor_m17AEF99E86E4EA714D24FAFF40B2B184AFEFAAE3,
	ScreenSpaceReflectionModel_get_settings_mF5C5F456B5D4E524C1C92646370DB490EFAE683A,
	ScreenSpaceReflectionModel_set_settings_mCA73C58C8BE7EED955AA2B45A2DF06BF013CBF0F,
	ScreenSpaceReflectionModel_Reset_mE164FA0AE97662F846EE6ABA20A1FD7CA6CE6BEB,
	ScreenSpaceReflectionModel__ctor_m618438D2169ADD79CCD261DAA3278BE2654DDA57,
	UserLutModel_get_settings_m82CD623690B42D918D81B70D294F7F56C7366AD5,
	UserLutModel_set_settings_m6D84900B98D22C6CBC1BD3C1744FE5C9D85D0878,
	UserLutModel_Reset_m32E91747CC6A6E9F5AB19E5242E2533AA8ADF7F9,
	UserLutModel__ctor_m6ED43BF3A5EAAC14CAC941EABD318AB87974D6D4,
	VignetteModel_get_settings_m0088EBD41E510D0FC5DF17FC133A98EEC83DAB63,
	VignetteModel_set_settings_mB247818E0FD41105B90761AE980C1CDC134B51A2,
	VignetteModel_Reset_m36D38CA5180A97991C8786D2DFE5FE31BD3EFDBB,
	VignetteModel__ctor_m37B9F390432277C45BA510DD3AF3E641B146544D,
	PostProcessingBehaviour_OnEnable_m8BADFBD1B04DD475B329022BCD897F94F2678755,
	PostProcessingBehaviour_OnPreCull_mDC3E596FCDDF46861B19AEDCEE7A030A462653E4,
	PostProcessingBehaviour_OnPreRender_mE53A4B7FDA37F6A3E3B617BEE2E71E984D9E3B0A,
	PostProcessingBehaviour_OnPostRender_m73A70E45F70D1B274F0824F02DC52C18FCFF65D3,
	PostProcessingBehaviour_OnRenderImage_mAFF54B8E5C2A7813F866143FA1F313F4463EE487,
	PostProcessingBehaviour_OnGUI_mD41B14C04DBCEFE9B3C41B04A1003EA7F470E92B,
	PostProcessingBehaviour_OnDisable_mA80612BCA42C3900E322386CAF8A750FEF1E0E42,
	PostProcessingBehaviour_ResetTemporalEffects_m8370A2742A0977EA53E9E47ACE07FB3C4381772B,
	PostProcessingBehaviour_CheckObservers_m9557CD7CB41BCC2E96B49079FC02CD7C7DC5B0AA,
	PostProcessingBehaviour_DisableComponents_mC1AE3448D19621891B04526D2FAD0F7C90F12D37,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PostProcessingBehaviour__ctor_mEBBEBD3D56E712F56F2604F1BB90926EC81F75D2,
	PostProcessingComponentBase_GetCameraFlags_m3C8D0EB0C179FD957F5D57CC88D4535D4F132C16,
	NULL,
	PostProcessingComponentBase_OnEnable_m0085392683268055715EAD66095A02DA5017F089,
	PostProcessingComponentBase_OnDisable_m446E74F6E6C3AD45ED6831F999C0C34BDE161B39,
	NULL,
	PostProcessingComponentBase__ctor_m95905EACEC14697C2FB1F6988D0B6AD44ED4C54A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PostProcessingContext_get_interrupted_m84F41C81E1BC876072A2B243111CAA26ABCE3B1F,
	PostProcessingContext_set_interrupted_m49B5E6F087E28EDD810507B98AC782525B3E0D9E,
	PostProcessingContext_Interrupt_mE079F46BCEDB8D2A9312E99718CE6C29C328D788,
	PostProcessingContext_Reset_m6715107A49BBB86B5B638808114670265B43EA17,
	PostProcessingContext_get_isGBufferAvailable_mC09D6470576F02B9AEB16401F649A99E9148CF11,
	PostProcessingContext_get_isHdr_m4B5F1AE2F5A5DF6AA3BDA14C7EC48D64C5AE55CB,
	PostProcessingContext_get_width_m4FAF966400473CC9916F061098C91333191DB4D1,
	PostProcessingContext_get_height_m846FF38F76BD6BA8B6384C70ED134BD01E43BDE2,
	PostProcessingContext_get_viewport_mCED91DA77E2AACCF2B70F1F712DADF5EADDDC58F,
	PostProcessingContext__ctor_m5B7385F53C874D3C245CC8E8D5ADCB8CF74E9B25,
	PostProcessingModel_get_enabled_m5D04672894E99E917383E5B2165FEC623D800885,
	PostProcessingModel_set_enabled_m8BBC51EA5A7FB95051AF25FC3C8FA1DD79594C37,
	NULL,
	PostProcessingModel_OnValidate_mD71A3DC68235ADB4482A6A9F5C85477750A7AD0D,
	PostProcessingModel__ctor_m6C73498EA865E867DFAC27A88B6D1F597CAAAC77,
	PostProcessingProfile__ctor_m31DA1F3AA712B6B80D8D58DCBAA8474100156DCE,
	ColorGradingCurve__ctor_m7A97F58ABE03C89193D1ED5D1882C6D99F020E1E,
	ColorGradingCurve_Cache_mE2681BA1052637190D45034BE4B4D5AE92254434,
	ColorGradingCurve_Evaluate_m4F55025ACE1BCD23F8DA0387885C18747F7AE6E8,
	GraphicsUtils_get_isLinearColorSpace_m893817B8B3CE926E73C5A87AB818D90C4CAD0306,
	GraphicsUtils_get_supportsDX11_m68C79F95A5FBED0A51EC9E919D44AB3646F680EA,
	GraphicsUtils_get_whiteTexture_mC3334B4B82001AA13E16180EBE587F7181FCF76D,
	GraphicsUtils_get_quad_m6B749345AD23DF051A0854E1A7DC5D145ED6D246,
	GraphicsUtils_Blit_mCC20B0EA9CB3F3835FF69005EAC7A68F3336FA9F,
	GraphicsUtils_ClearAndBlit_m2AAADE156F34D3F76D8283003FBC86D0AEFDBACE,
	GraphicsUtils_Destroy_m32BE15B5C9C7E49A6F396AB307260A8BC3B5A6EA,
	GraphicsUtils_Dispose_mF5E83C9144A7F81E8F5BD34431E21B4D3B52B320,
	MaterialFactory__ctor_m4349A2881D8319607ED9AA88B1BB9B05968B7020,
	MaterialFactory_Get_m9F25A1B3767C0E115F281F568051C19A5621AFB9,
	MaterialFactory_Dispose_mC7A897962122085E3867E048431AA523BAB3C743,
	RenderTextureFactory__ctor_mBC89C8B154571E51E112FEED9B669AC8DB508C45,
	RenderTextureFactory_Get_m60A31CA2C3799F5C48C188ABD53FAB5C4AF299B3,
	RenderTextureFactory_Get_m6360C458AC385DA8CD4482470A6448D8813F20A6,
	RenderTextureFactory_Release_m68EF13C168000B02D1B73D6D3006905DFA34819B,
	RenderTextureFactory_ReleaseAll_m45D549D5F66760B3C9DF4EE4C2F02CC0D8AE644A,
	RenderTextureFactory_Dispose_m157D256FDBA742A0F3D513AEA563E3CF183E713B,
	Uniforms__cctor_mC713CDFE19841DDF547AA4CBC0617FD5C1C04263,
	Uniforms__cctor_mA62A9DF34E30157CB2C7E0194F840F052CEE8EAA,
	Uniforms__cctor_mD87D137D0F5BF1412FDEB8D9B27539A7734B93F9,
	ArrowArray_get_mesh_m2FEDA26A5AF1A4EB45500B48D90C2A77143EC2A5,
	ArrowArray_set_mesh_m0FED37676A310829555143967E29C6CCF6589274,
	ArrowArray_get_columnCount_m322CB9227C6F92D5B85F51D1E76BF9FCA878CF6F,
	ArrowArray_set_columnCount_m5EBCBDA6CD7211BA1EA197DDC20365BDD75B9147,
	ArrowArray_get_rowCount_mDA2E4D8A35BD13A0080E40A9A95C330F6A2EE0E0,
	ArrowArray_set_rowCount_mEA4B53854D630F0FC2CDBAC9711527CFADCD40B7,
	ArrowArray_BuildMesh_mD8EE3BFD74DFFFB16F66A780C9CDCCD463ECB4BD,
	ArrowArray_Release_m468831C28553A7D8061AE5A0B521BCA42BC2F3C7,
	ArrowArray__ctor_mC31D6A2884B910FD3007BF4EF036BF1E3EC84503,
	Uniforms__cctor_m1A4F94C413A74873F53A1DBF41203964C333186E,
	Uniforms__cctor_m5EE7940F859512E0D626B64EE411D394433E8B75,
	Uniforms__cctor_mDCFD0EA62A65DF6DF00BE11F8CAB4FCCBD7A13DC,
	Uniforms__cctor_mEF0B1DF95C7597AAE3E734B58C95C5B7DD55547A,
	Uniforms__cctor_mCD39EEF0420035879C558A506C0FE77E00CCE22D,
	Uniforms__cctor_mAB9524CA45FFF53FC50B59A1C5637146EE370405,
	Uniforms__cctor_m3ACDDB63079CB403F19D61A0A96A12573F568312,
	Uniforms__cctor_m181AA37D964E0113FCE926E75B4A3C7A510F2F98,
	Uniforms__cctor_mADC5732B89158E0AD55B29B6E9C129738F3A2B4A,
	ReconstructionFilter__ctor_mFD306D50DD310004AB5F506EADCF325B0937DB18,
	ReconstructionFilter_CheckTextureFormatSupport_m5BAE17550AA500EB1DA582B6B6032D71FD70E1CD,
	ReconstructionFilter_IsSupported_m37BB8C07D34B96DC5246E67EBE453ED216E8C176,
	ReconstructionFilter_ProcessImage_m43E3DB760FCB6769EFD4ABA78D0BB5EA7AE95D8F,
	FrameBlendingFilter__ctor_mF0603488404518BA719F3DC2C3DE3086781097BE,
	FrameBlendingFilter_Dispose_mDFB3481B39ED1BC881C6E7A9ABB7C279E3A07339,
	FrameBlendingFilter_PushFrame_m8D30426B960859C77503A34DEB6C34AF1BEAB2F8,
	FrameBlendingFilter_BlendFrames_mEDFE6BAEF67327185FA062B887A8AF6A0087B93F,
	FrameBlendingFilter_CheckSupportCompression_mB650DD4D10F2C4D179F28CA3FCA216C8F2BF545D,
	FrameBlendingFilter_GetPreferredRenderTextureFormat_m1A74C8BD244DBA4002DDFA621E2D8B61627F83F8,
	FrameBlendingFilter_GetFrameRelative_m471D9972BD5D46529E9C8367F26234EC3E6D9565,
	Uniforms__cctor_m14B952A88249426EC2DEE575D407895ADE030AA3,
	Uniforms__cctor_mE35E923121972C1045D2185D98C19090D3748F58,
	Uniforms__cctor_mA2663CDFEC7B2ED77C78A899EC5CC903EC061BE2,
	Uniforms__cctor_mE896A281C010674DD689010BE6C91D3438899EA3,
	Settings_get_defaultSettings_m790BA9D65EDEA2C144DCFA9144D38071F2220BBA,
	FxaaQualitySettings__cctor_m88A2C5F3355258E247988B70690583A2E12F8D5B,
	FxaaConsoleSettings__cctor_m8CBE5237BF44F8CBA2A85E5B2B1E2DEC4B3E83EF,
	FxaaSettings_get_defaultSettings_mCA0F59291814B898CB55A5CFD38D853615A28537,
	TaaSettings_get_defaultSettings_m98B736C7C815ABD628506A59D2B5CABE28EEB8A0,
	Settings_get_defaultSettings_m2D6C780FB5483B1B7159C259B65F8049E24701B0,
	BloomSettings_set_thresholdLinear_m110754AE2464BC3D1436D6E0D482F4CF42A63B32_AdjustorThunk,
	BloomSettings_get_thresholdLinear_m53F5754536E0777F50F791F207844E986DC18AF7_AdjustorThunk,
	BloomSettings_get_defaultSettings_m541422CC17F842C57AE55A224BF3C53C768E1785,
	LensDirtSettings_get_defaultSettings_mEBABB0843318E82DFF53ABAAEBD74A981569EAC3,
	Settings_get_defaultSettings_mC8DEF8E5420A7AC375FF5164D2A11C6BA9D23A2B,
	DepthSettings_get_defaultSettings_m740227F0138C1604D884468ADE28C1E06A0A98FD,
	MotionVectorsSettings_get_defaultSettings_mD0F08A9A94F262C5AAC437C044E78FA10485CE72,
	Settings_get_defaultSettings_m75D16BE9820DC3F6A4B25D69DE521C35230CFFFD,
	Settings_get_defaultSettings_m1CF1CC3AFCD0C0CD5FE9F2C4D8042844ECA105A8,
	TonemappingSettings_get_defaultSettings_mC88317C18514F713304598A541DD0248ED338CB6,
	BasicSettings_get_defaultSettings_mF905204299C43D709646CB05B405D38A6A6F4DD8,
	ChannelMixerSettings_get_defaultSettings_mB4CD0904ACCD19543C1E3305EB479EF1C68ADD6D,
	LogWheelsSettings_get_defaultSettings_m5DCE15C9BAB587096E9CD29209EE5A3115F663D4,
	LinearWheelsSettings_get_defaultSettings_mC05B5B5123222C9800E3E59F00620B9F4BE37AE4,
	ColorWheelsSettings_get_defaultSettings_m37036621FD5F5BE60ACC53910CA2EBB0009973CA,
	CurvesSettings_get_defaultSettings_m1BE81E4DFBB87BDEB9B0C81D6934FA518837B361,
	Settings_get_defaultSettings_mA905C37C111AA5E39311404A909196136C50FC76,
	Settings_get_defaultSettings_m379831F7B7CF92CA85486AEFFCA53BC093DDB796,
	Settings_get_defaultSettings_mDE670379448F42DFB728D2F8F3D3DE98B8941D0A,
	Settings_get_defaultSettings_m2FDDC1FB7081FAE62C40B110267F4C3D0545985F,
	Settings_get_defaultSettings_m7A0B383860B9A801075380E5F797C5D9AF760939,
	Settings_get_defaultSettings_m9159627217232A842D921250845183A2A398081B,
	Settings_get_defaultSettings_m406A0B3CD5A263EB5BC1FE05F2DDDF8AF82404BB,
	Settings_get_defaultSettings_m4476B15B5C3BD8033730CF2D9B986FD67BF9523C,
	Settings_get_defaultSettings_m698C0098D4C46F5CE2E496960A5F6B97CBCEE21B,
	Settings_get_defaultSettings_mCF6865170EC5F2DC383576F0A6FAC4945AC6530C,
	Frame_CalculateWeight_m0D77630E6D4279DD16600C805650520D4DD01A33_AdjustorThunk,
	Frame_Release_m3FE08AF74AEB729A2A934FBD5F6844D949E0D808_AdjustorThunk,
	Frame_MakeRecord_m4643EE697F001944666AEB7CEA9060840A22B6FD_AdjustorThunk,
	Frame_MakeRecordRaw_m86A8B06A27C8677059E77C8B48786C1688DC014C_AdjustorThunk,
};
static const int32_t s_InvokerIndices[377] = 
{
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	26,
	26,
	23,
	26,
	275,
	26,
	23,
	10,
	102,
	102,
	10,
	14,
	10,
	26,
	23,
	102,
	156,
	23,
	102,
	10,
	10,
	14,
	26,
	26,
	26,
	26,
	23,
	23,
	23,
	102,
	23,
	26,
	23,
	102,
	987,
	1625,
	1625,
	1626,
	1627,
	1628,
	1628,
	1628,
	1629,
	1628,
	1628,
	1628,
	1629,
	10,
	14,
	9,
	10,
	23,
	26,
	23,
	23,
	23,
	102,
	10,
	655,
	1041,
	52,
	56,
	1630,
	23,
	23,
	102,
	23,
	23,
	26,
	23,
	102,
	23,
	23,
	23,
	1172,
	101,
	23,
	23,
	102,
	14,
	10,
	10,
	26,
	23,
	102,
	27,
	23,
	102,
	23,
	26,
	23,
	14,
	14,
	102,
	14,
	23,
	10,
	10,
	23,
	26,
	23,
	23,
	10,
	102,
	23,
	14,
	10,
	26,
	23,
	102,
	10,
	1017,
	1169,
	23,
	26,
	27,
	1636,
	1017,
	1637,
	1637,
	23,
	23,
	102,
	26,
	23,
	23,
	102,
	26,
	23,
	1638,
	1639,
	23,
	23,
	1641,
	1642,
	23,
	23,
	1646,
	1647,
	23,
	23,
	1651,
	1652,
	102,
	23,
	30,
	23,
	1656,
	1657,
	23,
	23,
	1659,
	1660,
	102,
	31,
	14,
	26,
	23,
	23,
	23,
	1669,
	1670,
	23,
	23,
	1672,
	1673,
	23,
	23,
	1675,
	1676,
	23,
	23,
	1678,
	1679,
	23,
	23,
	1681,
	1682,
	23,
	23,
	1684,
	1685,
	23,
	23,
	1687,
	1688,
	23,
	23,
	1690,
	1691,
	23,
	23,
	1693,
	1694,
	23,
	23,
	23,
	23,
	23,
	23,
	27,
	23,
	23,
	23,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	10,
	102,
	23,
	23,
	14,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	102,
	31,
	23,
	14,
	102,
	102,
	10,
	10,
	992,
	23,
	102,
	31,
	23,
	23,
	23,
	23,
	1696,
	23,
	987,
	49,
	49,
	4,
	4,
	308,
	1697,
	111,
	3,
	23,
	28,
	23,
	23,
	28,
	1698,
	26,
	23,
	23,
	3,
	3,
	3,
	14,
	26,
	10,
	32,
	10,
	32,
	157,
	23,
	23,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	23,
	23,
	102,
	1631,
	23,
	23,
	1632,
	1633,
	49,
	515,
	1634,
	3,
	3,
	3,
	3,
	1640,
	3,
	3,
	1643,
	1644,
	1645,
	275,
	655,
	1648,
	1649,
	1650,
	1653,
	1654,
	1655,
	1658,
	1661,
	1662,
	1663,
	1664,
	1665,
	1666,
	1667,
	1668,
	1671,
	1674,
	1677,
	1680,
	1683,
	1686,
	1689,
	1692,
	1695,
	1603,
	23,
	1632,
	1635,
};
static const Il2CppTokenRangePair s_rgctxIndices[9] = 
{
	{ 0x02000032, { 12, 3 } },
	{ 0x02000033, { 15, 2 } },
	{ 0x02000034, { 17, 2 } },
	{ 0x060000F6, { 0, 1 } },
	{ 0x060000F7, { 1, 1 } },
	{ 0x060000F8, { 2, 3 } },
	{ 0x060000F9, { 5, 5 } },
	{ 0x060000FA, { 10, 1 } },
	{ 0x060000FB, { 11, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[19] = 
{
	{ (Il2CppRGCTXDataType)1, 15127 },
	{ (Il2CppRGCTXDataType)1, 15128 },
	{ (Il2CppRGCTXDataType)1, 15129 },
	{ (Il2CppRGCTXDataType)3, 9431 },
	{ (Il2CppRGCTXDataType)3, 9432 },
	{ (Il2CppRGCTXDataType)3, 9433 },
	{ (Il2CppRGCTXDataType)3, 9434 },
	{ (Il2CppRGCTXDataType)3, 9435 },
	{ (Il2CppRGCTXDataType)3, 9436 },
	{ (Il2CppRGCTXDataType)3, 9437 },
	{ (Il2CppRGCTXDataType)3, 9438 },
	{ (Il2CppRGCTXDataType)2, 14850 },
	{ (Il2CppRGCTXDataType)3, 9439 },
	{ (Il2CppRGCTXDataType)3, 9440 },
	{ (Il2CppRGCTXDataType)2, 14881 },
	{ (Il2CppRGCTXDataType)3, 9441 },
	{ (Il2CppRGCTXDataType)2, 14885 },
	{ (Il2CppRGCTXDataType)3, 9442 },
	{ (Il2CppRGCTXDataType)2, 14889 },
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	377,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	9,
	s_rgctxIndices,
	19,
	s_rgctxValues,
	NULL,
};
